import { get, post, put, del } from './request'
import { PageResult } from './mine'

export interface Device {
  id?: number
  deviceCode: string
  deviceName: string
  deviceType: string
  mineId: number | string
  mineName?: string
  model: string
  location: string
  ratedPower: number
  status: number
  installTime?: string
  createTime?: string
}

export interface DevicePageParams {
  page?: number
  size?: number
  mineId?: number | string
  type?: string
  keyword?: string
}

export function page(params: DevicePageParams): Promise<PageResult<Device>> {
  return get<PageResult<Device>>('/devices', params)
}

export function all(): Promise<Device[]> {
  return get<Device[]>('/devices/all')
}

export function byMine(mineId: number | string): Promise<Device[]> {
  return get<Device[]>(`/devices/mine/${mineId}`)
}

export function getDevice(id: number | string): Promise<Device> {
  return get<Device>(`/devices/${id}`)
}

export function save(data: Device): Promise<any> {
  return post('/devices', data)
}

export function update(id: number | string, data: Device): Promise<any> {
  return put(`/devices/${id}`, data)
}

export function remove(id: number | string): Promise<any> {
  return del(`/devices/${id}`)
}
