import { post, get } from './request'

export interface LoginPayload {
  username: string
  password: string
}

export interface LoginResult {
  token: string
  tokenHead: string
  username: string
  nickname: string
  role: string
}

export interface UserInfo {
  username: string
  nickname: string
  role: string
}

export function login(data: LoginPayload): Promise<LoginResult> {
  return post<LoginResult>('/auth/login', data)
}

export function info(): Promise<UserInfo> {
  return get<UserInfo>('/auth/info')
}

export function logout(): Promise<any> {
  return post('/auth/logout')
}
