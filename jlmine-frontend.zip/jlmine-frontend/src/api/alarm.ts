import { get, put } from './request'

export interface Alarm {
  id?: number
  alarmCode: string
  deviceId: number | string
  deviceName?: string
  mineId: number | string
  mineName?: string
  alarmType: string
  level: number
  content: string
  triggerValue: number | string
  threshold: number | string
  status: number
  alarmTime: string
  handler?: string
  handleTime?: string
}

export interface AlarmPageParams {
  page?: number
  size?: number
  mineId?: number | string
  type?: string
  level?: number | string
  status?: number | string
  keyword?: string
}

export interface AlarmPageResult {
  total: number
  records: Alarm[]
}

export interface AlarmStats {
  total: number
  unhandled: number
  byType: Record<string, number>
  byLevel: Record<string, number>
  byStatus: Record<string, number>
}

export function page(params: AlarmPageParams): Promise<AlarmPageResult> {
  return get<AlarmPageResult>('/alarms', params)
}

export function getAlarm(id: number | string): Promise<Alarm> {
  return get<Alarm>(`/alarms/${id}`)
}

export function handle(id: number | string, data: { handler: string; status: number }): Promise<any> {
  return put(`/alarms/${id}/handle`, data)
}

export function stats(): Promise<AlarmStats> {
  return get<AlarmStats>('/alarms/stats')
}

export function latest(limit = 10): Promise<Alarm[]> {
  return get<Alarm[]>('/alarms/latest', { limit })
}
