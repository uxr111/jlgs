import { get, post, put, del } from './request'

export interface Mine {
  id?: number
  mineCode: string
  mineName: string
  region: string
  longitude: number
  latitude: number
  manager: string
  status: number
  createTime?: string
}

export interface MinePageParams {
  page?: number
  size?: number
  keyword?: string
}

export interface PageResult<T> {
  total: number
  page?: number
  size?: number
  records: T[]
}

export function page(params: MinePageParams): Promise<PageResult<Mine>> {
  return get<PageResult<Mine>>('/mines', params)
}

export function all(): Promise<Mine[]> {
  return get<Mine[]>('/mines/all')
}

export function getMine(id: number | string): Promise<Mine> {
  return get<Mine>(`/mines/${id}`)
}

export function save(data: Mine): Promise<any> {
  return post('/mines', data)
}

export function update(id: number | string, data: Mine): Promise<any> {
  return put(`/mines/${id}`, data)
}

export function remove(id: number | string): Promise<any> {
  return del(`/mines/${id}`)
}
