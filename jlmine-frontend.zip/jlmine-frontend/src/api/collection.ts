import { get, post } from './request'
import { PageResult } from './mine'

export interface CollectionRecord {
  id?: number
  deviceId: number | string
  deviceName?: string
  mineId: number | string
  outputTon: number
  temperature: number
  gasConcentration: number
  current: number
  runStatus: number
  collectTime: string
}

export interface LatestRecord {
  deviceId: number | string
  deviceName?: string
  deviceType?: string
  mineId?: number | string
  outputTon?: number
  temperature?: number
  gasConcentration?: number
  current?: number
  deviceStatus?: number
  collectTime?: string
}

export interface TrendPoint {
  time: string
  output: number
  temperature: number
  gas: number
}

export interface CollectionListParams {
  page?: number
  size?: number
  deviceId?: number | string
  mineId?: number | string
  startTime?: string
  endTime?: string
}

export function list(params: CollectionListParams): Promise<PageResult<CollectionRecord>> {
  return get<PageResult<CollectionRecord>>('/collection/list', params)
}

export function latest(): Promise<LatestRecord[]> {
  return get<LatestRecord[]>('/collection/latest')
}

export function trend(params: { mineId?: number | string; hours?: number }): Promise<TrendPoint[]> {
  return get<TrendPoint[]>('/collection/trend', params)
}

export function simulate(): Promise<any> {
  return post('/collection/simulate')
}
