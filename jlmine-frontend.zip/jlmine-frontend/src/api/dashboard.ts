import { get } from './request'

export interface Overview {
  mineCount: number
  deviceCount: number
  onlineDevice: number
  todayOutput: number
  unhandledAlarm: number
  totalAlarm: number
}

export interface MineOutput {
  mineName: string
  output: number
}

export interface DeviceStatusData {
  running: number
  stopped: number
  fault: number
}

export interface OutputTrendPoint {
  time: string
  output: number
  temperature: number
  gas: number
}

export interface DashboardAlarm {
  id: number
  alarmCode: string
  alarmType: string
  level: number
  content: string
  status: number
  alarmTime: string
  deviceName?: string
}

export function overview(): Promise<Overview> {
  return get<Overview>('/dashboard/overview')
}

export function mineOutput(): Promise<MineOutput[]> {
  return get<MineOutput[]>('/dashboard/mine-output')
}

export function deviceStatus(): Promise<DeviceStatusData> {
  return get<DeviceStatusData>('/dashboard/device-status')
}

export function outputTrend(hours = 24): Promise<OutputTrendPoint[]> {
  return get<OutputTrendPoint[]>('/dashboard/output-trend', { hours })
}

export function alarmList(limit = 10): Promise<DashboardAlarm[]> {
  return get<DashboardAlarm[]>('/dashboard/alarm-list', { limit })
}
