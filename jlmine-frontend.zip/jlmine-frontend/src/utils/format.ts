// Format utilities and Chinese text mappings

export function formatTime(ts: string | number | Date | undefined | null): string {
  if (!ts) return '-'
  let d: Date
  if (typeof ts === 'string') {
    // handle Java LocalDateTime array-like "[2026,9,29,10,0,0]" or ISO string
    if (/^\[.*\]$/.test(ts)) {
      try {
        const arr = JSON.parse(ts)
        if (Array.isArray(arr) && arr.length >= 6) {
          d = new Date(arr[0], (arr[1] || 1) - 1, arr[2], arr[3] || 0, arr[4] || 0, arr[5] || 0)
        } else {
          d = new Date(ts)
        }
      } catch (e) {
        d = new Date(ts)
      }
    } else {
      d = new Date(ts)
    }
  } else if (typeof ts === 'number') {
    d = new Date(ts)
  } else {
    d = ts as Date
  }
  if (isNaN(d.getTime())) return String(ts)
  const pad = (n: number) => (n < 10 ? '0' + n : '' + n)
  return (
    d.getFullYear() +
    '-' +
    pad(d.getMonth() + 1) +
    '-' +
    pad(d.getDate()) +
    ' ' +
    pad(d.getHours()) +
    ':' +
    pad(d.getMinutes()) +
    ':' +
    pad(d.getSeconds())
  )
}

const DEVICE_TYPE_MAP: Record<string, string> = {
  SHEARER: '采煤机',
  BELT: '运输皮带',
  VENTILATOR: '通风机',
  GAS_DETECTOR: '瓦斯检测仪',
  HOIST: '提升机'
}

export function deviceTypeText(type: string | undefined | null): string {
  if (!type) return '-'
  return DEVICE_TYPE_MAP[type] || type
}

export function deviceStatusText(status: number | string | undefined | null): string {
  if (status === undefined || status === null) return '-'
  const s = Number(status)
  if (s === 1) return '运行'
  if (s === 0) return '停机'
  if (s === 2) return '故障'
  return String(status)
}

export function deviceStatusTagType(status: number | undefined | null): string {
  const s = Number(status)
  if (s === 1) return 'success'
  if (s === 2) return 'danger'
  return 'info'
}

const ALARM_TYPE_MAP: Record<string, string> = {
  GAS_OVER: '瓦斯超限',
  TEMP_HIGH: '温度过高',
  DEVICE_FAULT: '设备故障'
}

export function alarmTypeText(type: string | undefined | null): string {
  if (!type) return '-'
  return ALARM_TYPE_MAP[type] || type
}

export function alarmLevelText(level: number | string | undefined | null): string {
  if (level === undefined || level === null) return '-'
  const l = Number(level)
  if (l === 1) return '低'
  if (l === 2) return '中'
  if (l === 3) return '高'
  return String(level)
}

export function alarmLevelTagType(level: number | undefined | null): string {
  const l = Number(level)
  if (l === 3) return 'danger'
  if (l === 2) return 'warning'
  return 'primary'
}

export function alarmStatusText(status: number | string | undefined | null): string {
  if (status === undefined || status === null) return '-'
  const s = Number(status)
  if (s === 0) return '未处理'
  if (s === 1) return '已处理'
  if (s === 2) return '已忽略'
  return String(status)
}

export function alarmStatusTagType(status: number | undefined | null): string {
  const s = Number(status)
  if (s === 1) return 'success'
  if (s === 2) return 'info'
  return 'danger'
}

export function mineStatusText(status: number | string | undefined | null): string {
  if (status === undefined || status === null) return '-'
  const s = Number(status)
  if (s === 1) return '生产'
  if (s === 0) return '停工'
  return String(status)
}
