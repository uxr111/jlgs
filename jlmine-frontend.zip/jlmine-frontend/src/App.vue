<template>
  <router-view />
</template>

<script setup lang="ts">
// Root component
</script>

<style>
#app {
  width: 100%;
  height: 100%;
}
html,
body {
  margin: 0;
  padding: 0;
  height: 100%;
  width: 100%;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue',
    Arial, 'PingFang SC', 'Microsoft YaHei', sans-serif;
}
</style>
