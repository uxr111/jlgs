<template>
  <div class="login-page">
    <div class="login-bg-grid"></div>
    <div class="login-card">
      <div class="login-header">
        <div class="login-logo">◆</div>
        <div class="login-title">吉林矿山采集监控系统</div>
        <div class="login-subtitle">Jilin Mine Collection Monitoring</div>
      </div>
      <el-form
        ref="formRef"
        :model="form"
        :rules="rules"
        class="login-form"
        @keyup.enter="onSubmit"
      >
        <el-form-item prop="username">
          <el-input
            v-model="form.username"
            placeholder="用户名"
            size="large"
            :prefix-icon="User"
          />
        </el-form-item>
        <el-form-item prop="password">
          <el-input
            v-model="form.password"
            type="password"
            placeholder="密码"
            size="large"
            show-password
            :prefix-icon="Lock"
          />
        </el-form-item>
        <el-button
          type="primary"
          size="large"
          class="login-btn"
          :loading="loading"
          @click="onSubmit"
        >
          登 录
        </el-button>
      </el-form>
      <div class="login-tip">演示账号：admin / Mjj@123456</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage, FormInstance } from 'element-plus'
import { User, Lock } from '@element-plus/icons-vue'
import { useUserStore } from '@/store/user'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

const formRef = ref<FormInstance>()
const loading = ref(false)

const form = reactive({
  username: 'admin',
  password: 'Mjj@123456'
})

const rules = {
  username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }]
}

async function onSubmit() {
  if (!formRef.value) return
  try {
    await formRef.value.validate()
  } catch (e) {
    return
  }
  loading.value = true
  try {
    await userStore.login({ username: form.username, password: form.password })
    ElMessage.success('登录成功')
    const redirect = (route.query.redirect as string) || '/screen'
    router.push(redirect)
  } catch (e) {
    // error already handled by interceptor
  } finally {
    loading.value = false
  }
}
</script>

<style scoped lang="scss">
.login-page {
  position: relative;
  width: 100vw;
  height: 100vh;
  overflow: hidden;
  background:
    radial-gradient(ellipse at top, rgba(0, 80, 160, 0.4) 0%, transparent 60%),
    radial-gradient(ellipse at bottom, rgba(0, 120, 200, 0.25) 0%, transparent 60%),
    linear-gradient(180deg, #050b1f 0%, #0a1530 50%, #050b1f 100%);
  display: flex;
  align-items: center;
  justify-content: center;
}

.login-bg-grid {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(64, 158, 255, 0.08) 1px, transparent 1px),
    linear-gradient(90deg, rgba(64, 158, 255, 0.08) 1px, transparent 1px);
  background-size: 50px 50px;
  pointer-events: none;
}

.login-card {
  position: relative;
  width: 380px;
  padding: 36px 32px 28px;
  background: rgba(10, 25, 55, 0.7);
  border: 1px solid rgba(64, 158, 255, 0.35);
  border-radius: 8px;
  box-shadow: 0 0 40px rgba(0, 80, 160, 0.4);
  backdrop-filter: blur(8px);
}

.login-card::before,
.login-card::after {
  content: '';
  position: absolute;
  width: 14px;
  height: 14px;
  border: 2px solid #00e5ff;
}
.login-card::before {
  top: -1px;
  left: -1px;
  border-right: none;
  border-bottom: none;
}
.login-card::after {
  bottom: -1px;
  right: -1px;
  border-left: none;
  border-top: none;
}

.login-header {
  text-align: center;
  margin-bottom: 28px;
}
.login-logo {
  font-size: 36px;
  color: #00e5ff;
  text-shadow: 0 0 12px #00e5ff;
  margin-bottom: 8px;
}
.login-title {
  font-size: 22px;
  color: #fff;
  letter-spacing: 2px;
  background: linear-gradient(90deg, #00e5ff, #4fc3f7);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}
.login-subtitle {
  font-size: 12px;
  color: #4fc3f7;
  margin-top: 4px;
  letter-spacing: 1px;
}

.login-form {
  margin-top: 10px;
}

:deep(.el-input__wrapper) {
  background: rgba(5, 20, 45, 0.6);
  box-shadow: 0 0 0 1px rgba(64, 158, 255, 0.3) inset;
}
:deep(.el-input__inner) {
  color: #cfe8ff;
}
:deep(.el-input__inner::placeholder) {
  color: #5a7a9a;
}

.login-btn {
  width: 100%;
  margin-top: 8px;
  background: linear-gradient(90deg, #1e90ff, #00b0ff);
  border: none;
  letter-spacing: 4px;
}

.login-tip {
  margin-top: 16px;
  text-align: center;
  font-size: 12px;
  color: #5a7a9a;
}
</style>
