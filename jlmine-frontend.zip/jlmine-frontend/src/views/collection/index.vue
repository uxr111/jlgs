<template>
  <div class="page-card">
    <div class="filter-bar">
      <el-select
        v-model="filterMineId"
        placeholder="选择矿区"
        clearable
        style="width: 180px"
        @change="onMineChange"
      >
        <el-option
          v-for="m in mineOptions"
          :key="m.id"
          :label="m.mineName"
          :value="m.id as any"
        />
      </el-select>
      <el-select
        v-model="filterDeviceId"
        placeholder="选择设备"
        clearable
        filterable
        style="width: 220px"
        @change="handleSearch"
      >
        <el-option
          v-for="d in deviceOptions"
          :key="d.id"
          :label="d.deviceName"
          :value="d.id as any"
        />
      </el-select>
      <el-date-picker
        v-model="timeRange"
        type="datetimerange"
        range-separator="至"
        start-placeholder="开始时间"
        end-placeholder="结束时间"
        value-format="YYYY-MM-DD HH:mm:ss"
        style="width: 380px"
        @change="handleSearch"
      />
      <el-button type="primary" @click="handleSearch">查询</el-button>
      <el-button @click="handleReset">重置</el-button>
      <el-button type="success" :loading="simulating" @click="handleSimulate">
        模拟采集
      </el-button>
    </div>

    <el-table v-loading="loading" :data="tableData" border stripe>
      <el-table-column prop="deviceName" label="设备名称" min-width="140" />
      <el-table-column label="产量(t)" width="110">
        <template #default="{ row }">{{ row.outputTon }}</template>
      </el-table-column>
      <el-table-column label="温度(℃)" width="110">
        <template #default="{ row }">
          <span :class="{ 'val-warn': row.temperature >= 80 }">{{ row.temperature }}</span>
        </template>
      </el-table-column>
      <el-table-column label="瓦斯(%)" width="110">
        <template #default="{ row }">
          <span :class="{ 'val-danger': row.gasConcentration >= 1 }">
            {{ row.gasConcentration }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="电流(A)" width="110">
        <template #default="{ row }">{{ row.current }}</template>
      </el-table-column>
      <el-table-column label="运行状态" width="100">
        <template #default="{ row }">
          <el-tag :type="deviceStatusTagType(row.runStatus) as any" size="small">
            {{ deviceStatusText(row.runStatus) }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="采集时间" width="180">
        <template #default="{ row }">{{ formatTime(row.collectTime) }}</template>
      </el-table-column>
    </el-table>

    <div class="pagination-bar">
      <el-pagination
        v-model:current-page="page"
        v-model:page-size="size"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next, jumper"
        @current-change="loadData"
        @size-change="loadData"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import * as collectionApi from '@/api/collection'
import type { CollectionRecord } from '@/api/collection'
import * as mineApi from '@/api/mine'
import type { Mine } from '@/api/mine'
import * as deviceApi from '@/api/device'
import type { Device } from '@/api/device'
import {
  formatTime,
  deviceStatusText,
  deviceStatusTagType
} from '@/utils/format'

const mineOptions = ref<Mine[]>([])
const deviceOptions = ref<Device[]>([])
const filterMineId = ref<number | string>('')
const filterDeviceId = ref<number | string>('')
const timeRange = ref<[string, string] | null>(null)
const page = ref(1)
const size = ref(10)
const total = ref(0)
const tableData = ref<CollectionRecord[]>([])
const loading = ref(false)
const simulating = ref(false)

async function loadMines() {
  try {
    const res = await mineApi.all()
    mineOptions.value = Array.isArray(res) ? res : []
  } catch (e) {
    // ignore
  }
}

async function loadDevices() {
  if (!filterMineId.value) {
    try {
      const res = await deviceApi.all()
      deviceOptions.value = Array.isArray(res) ? res : []
    } catch (e) {
      // ignore
    }
    return
  }
  try {
    const res = await deviceApi.byMine(filterMineId.value)
    deviceOptions.value = Array.isArray(res) ? res : []
  } catch (e) {
    // ignore
  }
}

async function onMineChange() {
  filterDeviceId.value = ''
  await loadDevices()
  handleSearch()
}

async function loadData() {
  loading.value = true
  try {
    const res = await collectionApi.list({
      page: page.value,
      size: size.value,
      mineId: filterMineId.value || undefined,
      deviceId: filterDeviceId.value || undefined,
      startTime: timeRange.value?.[0] || undefined,
      endTime: timeRange.value?.[1] || undefined
    })
    tableData.value = res?.records || []
    total.value = res?.total || 0
  } catch (e) {
    // handled
  } finally {
    loading.value = false
  }
}

function handleSearch() {
  page.value = 1
  loadData()
}

function handleReset() {
  filterMineId.value = ''
  filterDeviceId.value = ''
  timeRange.value = null
  page.value = 1
  loadDevices()
  loadData()
}

async function handleSimulate() {
  simulating.value = true
  try {
    const res: any = await collectionApi.simulate()
    ElMessage.success('模拟采集完成：' + (typeof res === 'string' ? res : '已生成数据'))
    loadData()
  } catch (e) {
    // handled
  } finally {
    simulating.value = false
  }
}

onMounted(async () => {
  await loadMines()
  await loadDevices()
  loadData()
})
</script>

<style scoped>
.val-warn {
  color: #e6a23c;
  font-weight: bold;
}
.val-danger {
  color: #f56c6c;
  font-weight: bold;
}
</style>
