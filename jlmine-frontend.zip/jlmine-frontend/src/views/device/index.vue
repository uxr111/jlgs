<template>
  <div class="page-card">
    <div class="table-toolbar">
      <div class="filter-bar">
        <el-select
          v-model="filterMineId"
          placeholder="选择矿区"
          clearable
          style="width: 180px"
          @change="handleSearch"
        >
          <el-option
            v-for="m in mineOptions"
            :key="m.id"
            :label="m.mineName"
            :value="m.id as any"
          />
        </el-select>
        <el-select
          v-model="filterType"
          placeholder="设备类型"
          clearable
          style="width: 160px"
          @change="handleSearch"
        >
          <el-option
            v-for="opt in typeOptions"
            :key="opt.value"
            :label="opt.label"
            :value="opt.value"
          />
        </el-select>
        <el-input
          v-model="keyword"
          placeholder="设备编码/名称/型号"
          clearable
          style="width: 240px"
          @keyup.enter="handleSearch"
          @clear="handleSearch"
        />
        <el-button type="primary" @click="handleSearch">查询</el-button>
        <el-button @click="handleReset">重置</el-button>
      </div>
      <el-button type="primary" @click="openCreate">+ 新增设备</el-button>
    </div>

    <el-table v-loading="loading" :data="tableData" border stripe>
      <el-table-column prop="deviceCode" label="设备编码" width="130" />
      <el-table-column prop="deviceName" label="设备名称" min-width="140" />
      <el-table-column label="类型" width="120">
        <template #default="{ row }">{{ deviceTypeText(row.deviceType) }}</template>
      </el-table-column>
      <el-table-column prop="mineName" label="所属矿区" min-width="120" />
      <el-table-column prop="model" label="型号" min-width="100" />
      <el-table-column prop="location" label="安装位置" min-width="120" />
      <el-table-column label="功率(kW)" width="100">
        <template #default="{ row }">{{ row.ratedPower }}</template>
      </el-table-column>
      <el-table-column label="状态" width="90">
        <template #default="{ row }">
          <el-tag :type="deviceStatusTagType(row.status) as any" size="small">
            {{ deviceStatusText(row.status) }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="安装时间" width="160">
        <template #default="{ row }">{{ formatTime(row.installTime) }}</template>
      </el-table-column>
      <el-table-column label="操作" width="160" fixed="right">
        <template #default="{ row }">
          <el-button type="primary" link @click="openEdit(row)">编辑</el-button>
          <el-button type="danger" link @click="handleDelete(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pagination-bar">
      <el-pagination
        v-model:current-page="page"
        v-model:page-size="size"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next, jumper"
        @current-change="loadData"
        @size-change="loadData"
      />
    </div>

    <el-dialog v-model="dialogVisible" :title="editId ? '编辑设备' : '新增设备'" width="600px">
      <el-form ref="formRef" :model="form" :rules="rules" label-width="100px">
        <el-form-item label="设备编码" prop="deviceCode">
          <el-input v-model="form.deviceCode" />
        </el-form-item>
        <el-form-item label="设备名称" prop="deviceName">
          <el-input v-model="form.deviceName" />
        </el-form-item>
        <el-form-item label="设备类型" prop="deviceType">
          <el-select v-model="form.deviceType" placeholder="请选择" style="width: 100%">
            <el-option
              v-for="opt in typeOptions"
              :key="opt.value"
              :label="opt.label"
              :value="opt.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="所属矿区" prop="mineId">
          <el-select v-model="form.mineId" placeholder="请选择" style="width: 100%">
            <el-option
              v-for="m in mineOptions"
              :key="m.id"
              :label="m.mineName"
              :value="m.id as any"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="型号" prop="model">
          <el-input v-model="form.model" />
        </el-form-item>
        <el-form-item label="安装位置" prop="location">
          <el-input v-model="form.location" />
        </el-form-item>
        <el-form-item label="额定功率" prop="ratedPower">
          <el-input-number v-model="form.ratedPower" :min="0" :precision="2" style="width: 100%" />
        </el-form-item>
        <el-form-item label="状态" prop="status">
          <el-radio-group v-model="form.status">
            <el-radio :value="1">运行</el-radio>
            <el-radio :value="0">停机</el-radio>
            <el-radio :value="2">故障</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="安装时间" prop="installTime">
          <el-date-picker
            v-model="form.installTime"
            type="datetime"
            value-format="YYYY-MM-DD HH:mm:ss"
            placeholder="选择安装时间"
            style="width: 100%"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="handleSave">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox, FormInstance } from 'element-plus'
import * as deviceApi from '@/api/device'
import type { Device } from '@/api/device'
import * as mineApi from '@/api/mine'
import type { Mine } from '@/api/mine'
import {
  formatTime,
  deviceTypeText,
  deviceStatusText,
  deviceStatusTagType
} from '@/utils/format'

const typeOptions = [
  { label: '采煤机', value: 'SHEARER' },
  { label: '运输皮带', value: 'BELT' },
  { label: '通风机', value: 'VENTILATOR' },
  { label: '瓦斯检测仪', value: 'GAS_DETECTOR' },
  { label: '提升机', value: 'HOIST' }
]

const mineOptions = ref<Mine[]>([])
const keyword = ref('')
const filterMineId = ref<number | string>('')
const filterType = ref('')
const page = ref(1)
const size = ref(10)
const total = ref(0)
const tableData = ref<Device[]>([])
const loading = ref(false)

const dialogVisible = ref(false)
const saving = ref(false)
const editId = ref<number | string>('')
const formRef = ref<FormInstance>()

const defaultForm = (): Device => ({
  deviceCode: '',
  deviceName: '',
  deviceType: 'SHEARER',
  mineId: '',
  model: '',
  location: '',
  ratedPower: 0,
  status: 1,
  installTime: ''
})
const form = reactive<Device>(defaultForm())

const rules = {
  deviceCode: [{ required: true, message: '请输入设备编码', trigger: 'blur' }],
  deviceName: [{ required: true, message: '请输入设备名称', trigger: 'blur' }],
  deviceType: [{ required: true, message: '请选择设备类型', trigger: 'change' }],
  mineId: [{ required: true, message: '请选择所属矿区', trigger: 'change' }]
}

async function loadMines() {
  try {
    const res = await mineApi.all()
    mineOptions.value = Array.isArray(res) ? res : []
  } catch (e) {
    // ignore
  }
}

async function loadData() {
  loading.value = true
  try {
    const res = await deviceApi.page({
      page: page.value,
      size: size.value,
      mineId: filterMineId.value || undefined,
      type: filterType.value || undefined,
      keyword: keyword.value
    })
    tableData.value = res?.records || []
    total.value = res?.total || 0
  } catch (e) {
    // handled
  } finally {
    loading.value = false
  }
}

function handleSearch() {
  page.value = 1
  loadData()
}

function handleReset() {
  keyword.value = ''
  filterMineId.value = ''
  filterType.value = ''
  page.value = 1
  loadData()
}

function openCreate() {
  editId.value = ''
  Object.assign(form, defaultForm())
  dialogVisible.value = true
}

function openEdit(row: Device) {
  editId.value = row.id || ''
  Object.assign(form, {
    deviceCode: row.deviceCode,
    deviceName: row.deviceName,
    deviceType: row.deviceType,
    mineId: row.mineId,
    model: row.model,
    location: row.location,
    ratedPower: Number(row.ratedPower),
    status: row.status,
    installTime: row.installTime
  })
  dialogVisible.value = true
}

async function handleSave() {
  if (!formRef.value) return
  try {
    await formRef.value.validate()
  } catch (e) {
    return
  }
  saving.value = true
  try {
    if (editId.value) {
      await deviceApi.update(editId.value, { ...form })
      ElMessage.success('修改成功')
    } else {
      await deviceApi.save({ ...form })
      ElMessage.success('新增成功')
    }
    dialogVisible.value = false
    loadData()
  } catch (e) {
    // handled
  } finally {
    saving.value = false
  }
}

async function handleDelete(row: Device) {
  try {
    await ElMessageBox.confirm(`确认删除设备「${row.deviceName}」吗？`, '提示', {
      type: 'warning'
    })
  } catch (e) {
    return
  }
  try {
    await deviceApi.remove(row.id!)
    ElMessage.success('删除成功')
    loadData()
  } catch (e) {
    // handled
  }
}

onMounted(async () => {
  await loadMines()
  loadData()
})
</script>
