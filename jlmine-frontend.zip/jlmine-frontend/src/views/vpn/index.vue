<template>
  <div class="vpn-page">
    <div class="vpn-bar">
      <div class="vpn-bar-left">
        <el-icon><Link /></el-icon>
        <span class="vpn-title">VPN 认证入口</span>
        <span class="vpn-url">{{ src }}</span>
      </div>
      <div class="vpn-bar-right">
        <el-button size="small" @click="reload">
          <el-icon><Refresh /></el-icon>
          刷新
        </el-button>
        <el-button size="small" type="primary" @click="openInNewTab">
          <el-icon><TopRight /></el-icon>
          新窗口打开
        </el-button>
      </div>
    </div>

    <div class="vpn-frame-wrap">
      <div v-if="loading" class="vpn-loading">
        <el-icon class="vpn-spin"><Loading /></el-icon>
        <span>正在加载 VPN 认证页面...</span>
      </div>
      <iframe
        v-if="showFrame"
        ref="frameRef"
        :src="src"
        class="vpn-frame"
        frameborder="0"
        allow="autoplay; clipboard-write; fullscreen"
        @load="onLoad"
        referrerpolicy="no-referrer"
      ></iframe>
      <div v-if="loadError" class="vpn-error">
        <el-icon size="40"><WarningFilled /></el-icon>
        <p class="vpn-error-title">VPN 页面无法在iframe中嵌入</p>
        <p class="vpn-error-desc">
          该站点可能设置了 X-Frame-Options / CSP frame-ancestors 限制，或使用了自签名证书。<br />
          请点击右上角"新窗口打开"直接访问。
        </p>
        <el-button type="primary" @click="openInNewTab">前往 VPN 页面</el-button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { Link, Refresh, TopRight, Loading, WarningFilled } from '@element-plus/icons-vue'

const src = 'https://111.26.195.108:8443/vpn/theme/auth_home.html'
const loading = ref(true)
const loadError = ref(false)
const showFrame = ref(true)
const frameRef = ref<HTMLIFrameElement | null>(null)

let loadTimer: ReturnType<typeof setTimeout> | null = null

function onLoad() {
  loading.value = false
  // 注意：因同源策略，跨域iframe即使load也可能无法访问内容；
  // 若目标设置了X-Frame-Options，浏览器会拒绝显示，此处无法可靠探测，
  // 故保留一个超时兜底：若8秒后仍处于loading则提示可能被拦截。
}

function reload() {
  loading.value = true
  loadError.value = false
  showFrame.value = false
  // 重新挂载iframe触发加载
  setTimeout(() => {
    showFrame.value = true
    startTimer()
  }, 50)
}

function openInNewTab() {
  window.open(src, '_blank', 'noopener,noreferrer')
}

function startTimer() {
  if (loadTimer) clearTimeout(loadTimer)
  loadTimer = setTimeout(() => {
    if (loading.value) {
      loadError.value = true
      loading.value = false
    }
  }, 8000)
}

onMounted(() => {
  startTimer()
})
</script>

<style scoped lang="scss">
.vpn-page {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: #fff;
  border-radius: 6px;
  overflow: hidden;
}
.vpn-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 16px;
  background: #f5f7fa;
  border-bottom: 1px solid #e6e6e6;
}
.vpn-bar-left {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #303133;
}
.vpn-title {
  font-weight: 600;
}
.vpn-url {
  color: #909399;
  font-size: 12px;
  margin-left: 4px;
}
.vpn-bar-right {
  display: flex;
  gap: 8px;
}
.vpn-frame-wrap {
  position: relative;
  flex: 1;
  overflow: hidden;
}
.vpn-frame {
  width: 100%;
  height: 100%;
  border: none;
  display: block;
}
.vpn-loading,
.vpn-error {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  background: #fff;
  color: #606266;
}
.vpn-spin {
  font-size: 32px;
  color: #409eff;
  animation: vpn-rot 1s linear infinite;
}
@keyframes vpn-rot {
  to {
    transform: rotate(360deg);
  }
}
.vpn-error-title {
  font-size: 16px;
  font-weight: 600;
  color: #f56c6c;
  margin: 4px 0 0;
}
.vpn-error-desc {
  text-align: center;
  font-size: 13px;
  line-height: 1.8;
  color: #909399;
  margin: 0 0 8px;
}
</style>
