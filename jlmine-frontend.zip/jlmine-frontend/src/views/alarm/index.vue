<template>
  <div class="page-card">
    <div class="filter-bar">
      <el-select
        v-model="filterMineId"
        placeholder="选择矿区"
        clearable
        style="width: 160px"
        @change="handleSearch"
      >
        <el-option
          v-for="m in mineOptions"
          :key="m.id"
          :label="m.mineName"
          :value="m.id as any"
        />
      </el-select>
      <el-select
        v-model="filterType"
        placeholder="告警类型"
        clearable
        style="width: 150px"
        @change="handleSearch"
      >
        <el-option label="瓦斯超限" value="GAS_OVER" />
        <el-option label="温度过高" value="TEMP_HIGH" />
        <el-option label="设备故障" value="DEVICE_FAULT" />
      </el-select>
      <el-select
        v-model="filterLevel"
        placeholder="告警级别"
        clearable
        style="width: 130px"
        @change="handleSearch"
      >
        <el-option label="低" :value="1" />
        <el-option label="中" :value="2" />
        <el-option label="高" :value="3" />
      </el-select>
      <el-select
        v-model="filterStatus"
        placeholder="告警状态"
        clearable
        style="width: 130px"
        @change="handleSearch"
      >
        <el-option label="未处理" :value="0" />
        <el-option label="已处理" :value="1" />
        <el-option label="已忽略" :value="2" />
      </el-select>
      <el-input
        v-model="keyword"
        placeholder="告警编码/设备名/内容"
        clearable
        style="width: 220px"
        @keyup.enter="handleSearch"
        @clear="handleSearch"
      />
      <el-button type="primary" @click="handleSearch">查询</el-button>
      <el-button @click="handleReset">重置</el-button>
    </div>

    <div class="stats-bar">
      <div class="stat-item">
        总数 <span class="stat-num">{{ statsData.total }}</span>
      </div>
      <div class="stat-item">
        未处理 <span class="stat-num danger">{{ statsData.unhandled }}</span>
      </div>
      <div class="stat-item">
        瓦斯超限 <span class="stat-num">{{ statsData.byType?.GAS_OVER || 0 }}</span>
      </div>
      <div class="stat-item">
        温度过高 <span class="stat-num">{{ statsData.byType?.TEMP_HIGH || 0 }}</span>
      </div>
      <div class="stat-item">
        设备故障 <span class="stat-num">{{ statsData.byType?.DEVICE_FAULT || 0 }}</span>
      </div>
    </div>

    <el-table v-loading="loading" :data="tableData" border stripe>
      <el-table-column prop="alarmCode" label="告警编码" width="140" />
      <el-table-column label="类型" width="110">
        <template #default="{ row }">{{ alarmTypeText(row.alarmType) }}</template>
      </el-table-column>
      <el-table-column label="级别" width="80">
        <template #default="{ row }">
          <el-tag :type="alarmLevelTagType(row.level) as any" size="small">
            {{ alarmLevelText(row.level) }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="deviceName" label="设备名称" min-width="120" />
      <el-table-column prop="mineName" label="所属矿区" min-width="120" />
      <el-table-column prop="content" label="告警内容" min-width="180" />
      <el-table-column label="触发值/阈值" width="140">
        <template #default="{ row }">
          {{ row.triggerValue }} / {{ row.threshold }}
        </template>
      </el-table-column>
      <el-table-column label="状态" width="100">
        <template #default="{ row }">
          <el-tag :type="alarmStatusTagType(row.status) as any" size="small">
            {{ alarmStatusText(row.status) }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="告警时间" width="160">
        <template #default="{ row }">{{ formatTime(row.alarmTime) }}</template>
      </el-table-column>
      <el-table-column label="操作" width="120" fixed="right">
        <template #default="{ row }">
          <el-button
            v-if="row.status === 0"
            type="primary"
            link
            @click="openHandle(row)"
          >
            处理
          </el-button>
          <span v-else style="color: #909399">{{ row.handler || '-' }}</span>
        </template>
      </el-table-column>
    </el-table>

    <div class="pagination-bar">
      <el-pagination
        v-model:current-page="page"
        v-model:page-size="size"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next, jumper"
        @current-change="loadData"
        @size-change="loadData"
      />
    </div>

    <el-dialog v-model="dialogVisible" title="处理告警" width="480px">
      <el-form ref="formRef" :model="handleForm" :rules="rules" label-width="90px">
        <el-form-item label="告警编码">
          <span>{{ currentAlarm?.alarmCode }}</span>
        </el-form-item>
        <el-form-item label="告警内容">
          <span>{{ currentAlarm?.content }}</span>
        </el-form-item>
        <el-form-item label="处理人" prop="handler">
          <el-input v-model="handleForm.handler" placeholder="请输入处理人" />
        </el-form-item>
        <el-form-item label="处理结果" prop="status">
          <el-radio-group v-model="handleForm.status">
            <el-radio :value="1">已处理</el-radio>
            <el-radio :value="2">已忽略</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="handleSave">确认</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, FormInstance } from 'element-plus'
import * as alarmApi from '@/api/alarm'
import type { Alarm, AlarmStats } from '@/api/alarm'
import * as mineApi from '@/api/mine'
import type { Mine } from '@/api/mine'
import {
  formatTime,
  alarmTypeText,
  alarmLevelText,
  alarmLevelTagType,
  alarmStatusText,
  alarmStatusTagType
} from '@/utils/format'

const mineOptions = ref<Mine[]>([])
const keyword = ref('')
const filterMineId = ref<number | string>('')
const filterType = ref('')
const filterLevel = ref<number | string>('')
const filterStatus = ref<number | string>('')
const page = ref(1)
const size = ref(10)
const total = ref(0)
const tableData = ref<Alarm[]>([])
const loading = ref(false)

const statsData = ref<AlarmStats>({
  total: 0,
  unhandled: 0,
  byType: {},
  byLevel: {},
  byStatus: {}
})

const dialogVisible = ref(false)
const saving = ref(false)
const formRef = ref<FormInstance>()
const currentAlarm = ref<Alarm | null>(null)
const handleForm = reactive({
  handler: '',
  status: 1
})

const rules = {
  handler: [{ required: true, message: '请输入处理人', trigger: 'blur' }],
  status: [{ required: true, message: '请选择处理结果', trigger: 'change' }]
}

async function loadMines() {
  try {
    const res = await mineApi.all()
    mineOptions.value = Array.isArray(res) ? res : []
  } catch (e) {
    // ignore
  }
}

async function loadData() {
  loading.value = true
  try {
    const res = await alarmApi.page({
      page: page.value,
      size: size.value,
      mineId: filterMineId.value || undefined,
      type: filterType.value || undefined,
      level: filterLevel.value || undefined,
      status: filterStatus.value || undefined,
      keyword: keyword.value
    })
    tableData.value = res?.records || []
    total.value = res?.total || 0
  } catch (e) {
    // handled
  } finally {
    loading.value = false
  }
}

async function loadStats() {
  try {
    const res = await alarmApi.stats()
    if (res) statsData.value = res
  } catch (e) {
    // ignore
  }
}

function handleSearch() {
  page.value = 1
  loadData()
  loadStats()
}

function handleReset() {
  keyword.value = ''
  filterMineId.value = ''
  filterType.value = ''
  filterLevel.value = ''
  filterStatus.value = ''
  page.value = 1
  loadData()
  loadStats()
}

function openHandle(row: Alarm) {
  currentAlarm.value = row
  handleForm.handler = ''
  handleForm.status = 1
  dialogVisible.value = true
}

async function handleSave() {
  if (!formRef.value || !currentAlarm.value) return
  try {
    await formRef.value.validate()
  } catch (e) {
    return
  }
  saving.value = true
  try {
    await alarmApi.handle(currentAlarm.value.id!, {
      handler: handleForm.handler,
      status: handleForm.status
    })
    ElMessage.success('处理成功')
    dialogVisible.value = false
    loadData()
    loadStats()
  } catch (e) {
    // handled
  } finally {
    saving.value = false
  }
}

onMounted(async () => {
  await loadMines()
  loadData()
  loadStats()
})
</script>

<style scoped>
.stats-bar {
  display: flex;
  flex-wrap: wrap;
  gap: 24px;
  padding: 12px 16px;
  margin-bottom: 12px;
  background: #f5f7fa;
  border-radius: 4px;
  font-size: 14px;
  color: #606266;
}
.stat-num {
  font-size: 18px;
  font-weight: bold;
  color: #303133;
  margin-left: 4px;
}
.stat-num.danger {
  color: #f56c6c;
}
</style>
