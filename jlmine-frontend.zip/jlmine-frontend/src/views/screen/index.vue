<template>
  <div class="screen-container">
    <div class="screen-header">
      <div class="screen-back" @click="goAdmin">返回管理后台</div>
      <div class="screen-title">吉林矿山采集监控中心</div>
      <div class="screen-clock">{{ currentTime }}</div>
    </div>

    <div class="screen-body">
      <!-- top: data cards -->
      <div class="screen-row-top">
        <DataCard title="矿区数" :value="overview.mineCount" unit="个" color="#00e5ff" icon="◆" />
        <DataCard title="在线设备" :value="overview.onlineDevice" unit="台" color="#00e676" icon="■" />
        <DataCard title="今日产量" :value="overview.todayOutput" unit="t" color="#ffb74d" icon="▲" />
        <DataCard title="待处理告警" :value="overview.unhandledAlarm" unit="条" color="#ff5252" icon="●" />
      </div>

      <!-- left top: trend -->
      <div class="panel">
        <div class="panel-title">
          <span>产量趋势（24小时）</span>
          <span class="panel-sub">温度/瓦斯同步</span>
        </div>
        <div class="panel-body">
          <LineTrend :data="trendData" />
        </div>
      </div>

      <!-- center: mine map -->
      <div class="panel">
        <div class="panel-title">
          <span>矿区分布</span>
          <span class="panel-sub">{{ activeMineName || '全部矿区' }}</span>
        </div>
        <div class="panel-body">
          <div class="mine-map">
            <div
              v-for="(m, idx) in minePoints"
              :key="idx"
              class="mine-point"
              :class="{ active: activeMineId === m.id }"
              :style="{ left: m.x + '%', top: m.y + '%' }"
              @click="onSelectMine(m)"
            >
              <div class="mp-dot"></div>
              <div class="mp-name">{{ m.name }}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- right top: device status pie -->
      <div class="panel">
        <div class="panel-title">
          <span>设备状态</span>
          <span class="panel-sub">运行/停机/故障</span>
        </div>
        <div class="panel-body">
          <DeviceStatusPie :data="deviceStatus" />
        </div>
      </div>

      <!-- left bottom: mine output bar -->
      <div class="panel">
        <div class="panel-title">
          <span>各矿区产量</span>
          <span class="panel-sub">吨</span>
        </div>
        <div class="panel-body">
          <MineOutputBar :data="mineOutputData" />
        </div>
      </div>

      <!-- right bottom: alarm list -->
      <div class="panel">
        <div class="panel-title">
          <span>最新告警</span>
          <span class="panel-sub">{{ alarmList.length }} 条</span>
        </div>
        <div class="panel-body">
          <div class="alarm-list">
            <div class="scroll-wrap">
              <div class="scroll-inner">
                <div
                  v-for="(a, idx) in alarmListDouble"
                  :key="idx"
                  class="alarm-row"
                  :class="{ unhandled: a.status === 0 }"
                >
                  <span class="ar-time">{{ formatTime(a.alarmTime) }}</span>
                  <span class="ar-tag">{{ alarmTypeText(a.alarmType) }}</span>
                  <span class="ar-tag">L{{ a.level }}</span>
                  <span class="ar-content">
                    {{ a.deviceName }} {{ a.content }}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onBeforeUnmount } from 'vue'
import { useRouter } from 'vue-router'
import * as dashboardApi from '@/api/dashboard'
import type { Overview, MineOutput, DeviceStatusData, OutputTrendPoint, DashboardAlarm } from '@/api/dashboard'
import { all as allMines } from '@/api/mine'
import type { Mine } from '@/api/mine'
import { formatTime, alarmTypeText } from '@/utils/format'
import DataCard from '@/components/charts/DataCard.vue'
import LineTrend from '@/components/charts/LineTrend.vue'
import MineOutputBar from '@/components/charts/MineOutputBar.vue'
import DeviceStatusPie from '@/components/charts/DeviceStatusPie.vue'
import '@/styles/screen.scss'

const router = useRouter()

const overview = ref<Overview>({
  mineCount: 0,
  deviceCount: 0,
  onlineDevice: 0,
  todayOutput: 0,
  unhandledAlarm: 0,
  totalAlarm: 0
})

const trendData = ref<OutputTrendPoint[]>([])
const mineOutputData = ref<MineOutput[]>([])
const deviceStatus = ref<DeviceStatusData>({ running: 0, stopped: 0, fault: 0 })
const alarmList = ref<DashboardAlarm[]>([])
const mineList = ref<Mine[]>([])
const activeMineId = ref<number | string>('')

const activeMineName = computed(() => {
  const m = mineList.value.find((x) => String(x.id) === String(activeMineId.value))
  return m?.mineName || ''
})

interface MinePointUI {
  id: number | string
  name: string
  x: number
  y: number
}

const minePoints = computed<MinePointUI[]>(() => {
  // distribute points across the map area
  const total = mineList.value.length
  if (total === 0) return []
  const cols = Math.max(1, Math.ceil(Math.sqrt(total)))
  const rows = Math.max(1, Math.ceil(total / cols))
  const padX = 12
  const padY = 14
  return mineList.value.map((m, i) => {
    const row = Math.floor(i / cols)
    const col = i % cols
    const x = cols > 1 ? padX + (col * (100 - 2 * padX)) / (cols - 1) : 50
    const y = rows > 1 ? padY + (row * (100 - 2 * padY)) / (rows - 1) : 50
    return { id: m.id as any, name: m.mineName, x, y }
  })
})

const alarmListDouble = computed(() => {
  return [...alarmList.value, ...alarmList.value]
})

const currentTime = ref('')

function updateTime() {
  const d = new Date()
  const pad = (n: number) => (n < 10 ? '0' + n : '' + n)
  currentTime.value =
    d.getFullYear() +
    '-' +
    pad(d.getMonth() + 1) +
    '-' +
    pad(d.getDate()) +
    ' ' +
    pad(d.getHours()) +
    ':' +
    pad(d.getMinutes()) +
    ':' +
    pad(d.getSeconds())
}

async function loadOverview() {
  try {
    const d = await dashboardApi.overview()
    if (d) overview.value = d
  } catch (e) {
    // ignore polling errors
  }
}

async function loadTrend() {
  try {
    const d = await dashboardApi.outputTrend(24)
    if (Array.isArray(d)) trendData.value = d
  } catch (e) {
    // ignore
  }
}

async function loadMineOutput() {
  try {
    const d = await dashboardApi.mineOutput()
    if (Array.isArray(d)) mineOutputData.value = d
  } catch (e) {
    // ignore
  }
}

async function loadDeviceStatus() {
  try {
    const d = await dashboardApi.deviceStatus()
    if (d) deviceStatus.value = d
  } catch (e) {
    // ignore
  }
}

async function loadAlarmList() {
  try {
    const d = await dashboardApi.alarmList(10)
    if (Array.isArray(d)) alarmList.value = d
  } catch (e) {
    // ignore
  }
}

async function loadMines() {
  try {
    const d = await allMines()
    if (Array.isArray(d)) mineList.value = d
  } catch (e) {
    // ignore
  }
}

function onSelectMine(m: MinePointUI) {
  if (activeMineId.value === m.id) {
    activeMineId.value = ''
  } else {
    activeMineId.value = m.id
  }
  loadTrend()
  loadMineOutput()
}

function goAdmin() {
  router.push('/mine')
}

let timer: number | null = null
let clockTimer: number | null = null

onMounted(async () => {
  updateTime()
  await Promise.all([
    loadOverview(),
    loadTrend(),
    loadMineOutput(),
    loadDeviceStatus(),
    loadAlarmList(),
    loadMines()
  ])
  timer = window.setInterval(async () => {
    await Promise.all([loadOverview(), loadAlarmList()])
  }, 5000)
  clockTimer = window.setInterval(updateTime, 1000)
})

onBeforeUnmount(() => {
  if (timer !== null) {
    clearInterval(timer)
    timer = null
  }
  if (clockTimer !== null) {
    clearInterval(clockTimer)
    clockTimer = null
  }
})
</script>
