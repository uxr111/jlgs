<template>
  <div class="page-card">
    <div class="table-toolbar">
      <div class="filter-bar">
        <el-input
          v-model="keyword"
          placeholder="矿区编码/名称/区域/负责人"
          clearable
          style="width: 260px"
          @keyup.enter="handleSearch"
          @clear="handleSearch"
        />
        <el-button type="primary" @click="handleSearch">查询</el-button>
        <el-button @click="handleReset">重置</el-button>
      </div>
      <el-button type="primary" @click="openCreate">+ 新增矿区</el-button>
    </div>

    <el-table v-loading="loading" :data="tableData" border stripe>
      <el-table-column prop="mineCode" label="矿区编码" width="120" />
      <el-table-column prop="mineName" label="矿区名称" min-width="140" />
      <el-table-column prop="region" label="区域" min-width="120" />
      <el-table-column label="经度" width="110">
        <template #default="{ row }">{{ formatNum(row.longitude) }}</template>
      </el-table-column>
      <el-table-column label="纬度" width="110">
        <template #default="{ row }">{{ formatNum(row.latitude) }}</template>
      </el-table-column>
      <el-table-column prop="manager" label="负责人" width="100" />
      <el-table-column label="状态" width="100">
        <template #default="{ row }">
          <el-switch
            v-model="row.status"
            :active-value="1"
            :inactive-value="0"
            active-text="生产"
            inactive-text="停工"
            @change="(val) => handleStatusChange(row, val)"
          />
        </template>
      </el-table-column>
      <el-table-column label="创建时间" width="160">
        <template #default="{ row }">{{ formatTime(row.createTime) }}</template>
      </el-table-column>
      <el-table-column label="操作" width="160" fixed="right">
        <template #default="{ row }">
          <el-button type="primary" link @click="openEdit(row)">编辑</el-button>
          <el-button type="danger" link @click="handleDelete(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pagination-bar">
      <el-pagination
        v-model:current-page="page"
        v-model:page-size="size"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next, jumper"
        @current-change="loadData"
        @size-change="loadData"
      />
    </div>

    <el-dialog v-model="dialogVisible" :title="editId ? '编辑矿区' : '新增矿区'" width="560px">
      <el-form ref="formRef" :model="form" :rules="rules" label-width="90px">
        <el-form-item label="矿区编码" prop="mineCode">
          <el-input v-model="form.mineCode" placeholder="例如 JLM001" />
        </el-form-item>
        <el-form-item label="矿区名称" prop="mineName">
          <el-input v-model="form.mineName" />
        </el-form-item>
        <el-form-item label="区域" prop="region">
          <el-input v-model="form.region" placeholder="例如 吉林省白山市" />
        </el-form-item>
        <el-form-item label="经度" prop="longitude">
          <el-input-number v-model="form.longitude" :precision="6" :step="0.000001" :controls="false" style="width: 100%" />
        </el-form-item>
        <el-form-item label="纬度" prop="latitude">
          <el-input-number v-model="form.latitude" :precision="6" :step="0.000001" :controls="false" style="width: 100%" />
        </el-form-item>
        <el-form-item label="负责人" prop="manager">
          <el-input v-model="form.manager" />
        </el-form-item>
        <el-form-item label="状态" prop="status">
          <el-radio-group v-model="form.status">
            <el-radio :value="1">生产</el-radio>
            <el-radio :value="0">停工</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="handleSave">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox, FormInstance } from 'element-plus'
import * as mineApi from '@/api/mine'
import type { Mine } from '@/api/mine'
import { formatTime } from '@/utils/format'

const keyword = ref('')
const page = ref(1)
const size = ref(10)
const total = ref(0)
const tableData = ref<Mine[]>([])
const loading = ref(false)

const dialogVisible = ref(false)
const saving = ref(false)
const editId = ref<number | string>('')
const formRef = ref<FormInstance>()

const defaultForm = (): Mine => ({
  mineCode: '',
  mineName: '',
  region: '',
  longitude: 0,
  latitude: 0,
  manager: '',
  status: 1
})
const form = reactive<Mine>(defaultForm())

const rules = {
  mineCode: [{ required: true, message: '请输入矿区编码', trigger: 'blur' }],
  mineName: [{ required: true, message: '请输入矿区名称', trigger: 'blur' }],
  region: [{ required: true, message: '请输入区域', trigger: 'blur' }]
}

function formatNum(n: number | string | undefined | null) {
  if (n === undefined || n === null || n === '') return '-'
  const num = Number(n)
  if (isNaN(num)) return String(n)
  return num.toFixed(6)
}

async function loadData() {
  loading.value = true
  try {
    const res = await mineApi.page({
      page: page.value,
      size: size.value,
      keyword: keyword.value
    })
    tableData.value = res?.records || []
    total.value = res?.total || 0
  } catch (e) {
    // handled
  } finally {
    loading.value = false
  }
}

function handleSearch() {
  page.value = 1
  loadData()
}

function handleReset() {
  keyword.value = ''
  page.value = 1
  loadData()
}

function openCreate() {
  editId.value = ''
  Object.assign(form, defaultForm())
  dialogVisible.value = true
}

function openEdit(row: Mine) {
  editId.value = row.id || ''
  Object.assign(form, {
    mineCode: row.mineCode,
    mineName: row.mineName,
    region: row.region,
    longitude: Number(row.longitude),
    latitude: Number(row.latitude),
    manager: row.manager,
    status: row.status
  })
  dialogVisible.value = true
}

async function handleSave() {
  if (!formRef.value) return
  try {
    await formRef.value.validate()
  } catch (e) {
    return
  }
  saving.value = true
  try {
    if (editId.value) {
      await mineApi.update(editId.value, { ...form })
      ElMessage.success('修改成功')
    } else {
      await mineApi.save({ ...form })
      ElMessage.success('新增成功')
    }
    dialogVisible.value = false
    loadData()
  } catch (e) {
    // handled
  } finally {
    saving.value = false
  }
}

async function handleDelete(row: Mine) {
  try {
    await ElMessageBox.confirm(`确认删除矿区「${row.mineName}」吗？`, '提示', {
      type: 'warning'
    })
  } catch (e) {
    return
  }
  try {
    await mineApi.remove(row.id!)
    ElMessage.success('删除成功')
    loadData()
  } catch (e) {
    // handled
  }
}

async function handleStatusChange(row: Mine, val: any) {
  try {
    await mineApi.update(row.id!, {
      mineCode: row.mineCode,
      mineName: row.mineName,
      region: row.region,
      longitude: Number(row.longitude),
      latitude: Number(row.latitude),
      manager: row.manager,
      status: Number(val)
    })
    ElMessage.success('状态更新成功')
  } catch (e) {
    row.status = val === 1 ? 0 : 1
  }
}

onMounted(() => {
  loadData()
})
</script>
