import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router'
import { getToken } from '@/utils/auth'

const routes: RouteRecordRaw[] = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/login/index.vue'),
    meta: { requiresAuth: false }
  },
  {
    path: '/',
    component: () => import('@/layout/ScreenLayout.vue'),
    redirect: '/screen',
    meta: { requiresAuth: true },
    children: [
      {
        path: 'screen',
        name: 'Screen',
        component: () => import('@/views/screen/index.vue'),
        meta: { title: '监控大屏', requiresAuth: true }
      }
    ]
  },
  {
    path: '/admin',
    component: () => import('@/layout/Layout.vue'),
    redirect: '/mine',
    meta: { requiresAuth: true },
    children: [
      {
        path: '/mine',
        name: 'Mine',
        component: () => import('@/views/mine/index.vue'),
        meta: { title: '矿区管理', requiresAuth: true }
      },
      {
        path: '/device',
        name: 'Device',
        component: () => import('@/views/device/index.vue'),
        meta: { title: '设备管理', requiresAuth: true }
      },
      {
        path: '/collection',
        name: 'Collection',
        component: () => import('@/views/collection/index.vue'),
        meta: { title: '采集数据', requiresAuth: true }
      },
      {
        path: '/alarm',
        name: 'Alarm',
        component: () => import('@/views/alarm/index.vue'),
        meta: { title: '告警列表', requiresAuth: true }
      },
      {
        path: '/vpn',
        name: 'Vpn',
        component: () => import('@/views/vpn/index.vue'),
        meta: { title: 'VPN入口', requiresAuth: true }
      }
    ]
  },
  {
    path: '/:pathMatch(.*)*',
    redirect: '/'
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

const WHITE_LIST = ['/login']

router.beforeEach((to, _from, next) => {
  const hasToken = !!getToken()
  if (hasToken) {
    if (to.path === '/login') {
      next({ path: '/' })
    } else {
      next()
    }
  } else {
    if (WHITE_LIST.includes(to.path) || to.meta.requiresAuth === false) {
      next()
    } else {
      next(`/login?redirect=${encodeURIComponent(to.fullPath)}`)
    }
  }
})

export default router
