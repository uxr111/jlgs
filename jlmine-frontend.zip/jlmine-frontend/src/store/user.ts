import { defineStore } from 'pinia'
import { login as loginApi, logout as logoutApi } from '@/api/auth'
import {
  getToken,
  setToken,
  removeToken,
  getUser,
  setUser,
  removeUser
} from '@/utils/auth'

interface UserInfo {
  username: string
  nickname: string
  role: string
}

interface UserState {
  token: string
  username: string
  nickname: string
  role: string
}

export const useUserStore = defineStore('user', {
  state: (): UserState => {
    const userStr = getUser()
    let username = ''
    let nickname = ''
    let role = ''
    if (userStr) {
      try {
        const u: UserInfo = JSON.parse(userStr)
        username = u.username || ''
        nickname = u.nickname || ''
        role = u.role || ''
      } catch (e) {
        // ignore parse error
      }
    }
    return {
      token: getToken(),
      username,
      nickname,
      role
    }
  },
  actions: {
    async login(payload: { username: string; password: string }) {
      const data: any = await loginApi(payload)
      const token = (data && (data.token || data.tokenHead + data.token)) || ''
      this.token = token
      this.username = data?.username || payload.username
      this.nickname = data?.nickname || data?.username || payload.username
      this.role = data?.role || ''
      setToken(token)
      const user: UserInfo = {
        username: this.username,
        nickname: this.nickname,
        role: this.role
      }
      setUser(JSON.stringify(user))
      return data
    },
    async logout() {
      try {
        await logoutApi()
      } catch (e) {
        // ignore
      }
      this.reset()
    },
    reset() {
      this.token = ''
      this.username = ''
      this.nickname = ''
      this.role = ''
      removeToken()
      removeUser()
    }
  }
})
