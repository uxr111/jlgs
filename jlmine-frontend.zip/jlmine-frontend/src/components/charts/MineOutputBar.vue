<template>
  <div ref="chartRef" class="chart-box"></div>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount, watch } from 'vue'
import * as echarts from 'echarts'

interface BarData {
  mineName: string
  output: number
}

const props = defineProps<{
  data: BarData[]
}>()

const chartRef = ref<HTMLDivElement | null>(null)
let chart: echarts.ECharts | null = null

function buildOption() {
  const data = props.data || []
  return {
    backgroundColor: 'transparent',
    grid: { left: 80, right: 20, top: 20, bottom: 30 },
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      backgroundColor: 'rgba(0,30,60,0.85)',
      borderColor: '#1e90ff',
      textStyle: { color: '#fff' }
    },
    xAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#2c5a8a' } },
      axisLabel: { color: '#8db6d8' },
      splitLine: { lineStyle: { color: 'rgba(64,158,255,0.1)' } }
    },
    yAxis: {
      type: 'category',
      data: data.map((d) => d.mineName),
      axisLine: { lineStyle: { color: '#2c5a8a' } },
      axisLabel: { color: '#cfe8ff' }
    },
    series: [
      {
        name: '产量(t)',
        type: 'bar',
        data: data.map((d) => d.output),
        barWidth: 14,
        itemStyle: {
          borderRadius: [0, 4, 4, 0],
          color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
            { offset: 0, color: '#1e90ff' },
            { offset: 1, color: '#00e5ff' }
          ])
        },
        label: {
          show: true,
          position: 'right',
          color: '#cfe8ff',
          fontSize: 11
        }
      }
    ]
  }
}

function renderChart() {
  if (!chart) return
  chart.setOption(buildOption())
}

function handleResize() {
  chart && chart.resize()
}

onMounted(() => {
  if (chartRef.value) {
    chart = echarts.init(chartRef.value)
    chart.setOption(buildOption())
    window.addEventListener('resize', handleResize)
  }
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', handleResize)
  chart && chart.dispose()
  chart = null
})

watch(
  () => props.data,
  () => renderChart(),
  { deep: true }
)
</script>
