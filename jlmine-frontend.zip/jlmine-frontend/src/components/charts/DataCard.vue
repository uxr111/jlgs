<template>
  <div class="panel">
    <div class="data-card">
      <div class="dc-title">{{ title }}</div>
      <div class="dc-value" :style="{ color: color }">
        {{ value }}<span class="dc-unit">{{ unit }}</span>
      </div>
      <div class="dc-icon" :style="{ color: color }">{{ icon }}</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { toRefs } from 'vue'

interface Props {
  title: string
  value: number | string
  unit?: string
  color?: string
  icon?: string
}

const props = withDefaults(defineProps<Props>(), {
  unit: '',
  color: '#00e5ff',
  icon: '◆'
})

// keep reactive reference (no-op, but ensures typing)
void toRefs(props)
</script>
