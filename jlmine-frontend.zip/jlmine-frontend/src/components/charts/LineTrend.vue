<template>
  <div ref="chartRef" class="chart-box"></div>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount, watch } from 'vue'
import * as echarts from 'echarts'

interface TrendPoint {
  time: string
  output: number
  temperature: number
  gas: number
}

const props = defineProps<{
  data: TrendPoint[]
}>()

const chartRef = ref<HTMLDivElement | null>(null)
let chart: echarts.ECharts | null = null

function buildOption() {
  const data = props.data || []
  const times = data.map((d) => d.time)
  const outputs = data.map((d) => d.output)
  const temps = data.map((d) => d.temperature)
  const gases = data.map((d) => d.gas)
  return {
    backgroundColor: 'transparent',
    grid: { left: 40, right: 50, top: 40, bottom: 30 },
    legend: {
      data: ['产量(t)', '温度(℃)', '瓦斯(%)'],
      textStyle: { color: '#8db6d8' },
      top: 5
    },
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(0,30,60,0.85)',
      borderColor: '#1e90ff',
      textStyle: { color: '#fff' }
    },
    xAxis: {
      type: 'category',
      data: times,
      axisLine: { lineStyle: { color: '#2c5a8a' } },
      axisLabel: { color: '#8db6d8', fontSize: 10 }
    },
    yAxis: [
      {
        type: 'value',
        name: '产量',
        nameTextStyle: { color: '#8db6d8' },
        axisLine: { lineStyle: { color: '#2c5a8a' } },
        axisLabel: { color: '#8db6d8' },
        splitLine: { lineStyle: { color: 'rgba(64,158,255,0.1)' } }
      },
      {
        type: 'value',
        name: '温度/瓦斯',
        nameTextStyle: { color: '#8db6d8' },
        axisLine: { lineStyle: { color: '#2c5a8a' } },
        axisLabel: { color: '#8db6d8' },
        splitLine: { show: false }
      }
    ],
    series: [
      {
        name: '产量(t)',
        type: 'line',
        smooth: true,
        symbol: 'circle',
        symbolSize: 6,
        data: outputs,
        itemStyle: { color: '#00e5ff' },
        lineStyle: { width: 2, color: '#00e5ff' },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: 'rgba(0,229,255,0.4)' },
            { offset: 1, color: 'rgba(0,229,255,0.02)' }
          ])
        }
      },
      {
        name: '温度(℃)',
        type: 'line',
        yAxisIndex: 1,
        smooth: true,
        symbol: 'circle',
        symbolSize: 5,
        data: temps,
        itemStyle: { color: '#ffb74d' },
        lineStyle: { width: 2, color: '#ffb74d' }
      },
      {
        name: '瓦斯(%)',
        type: 'line',
        yAxisIndex: 1,
        smooth: true,
        symbol: 'circle',
        symbolSize: 5,
        data: gases,
        itemStyle: { color: '#ff5252' },
        lineStyle: { width: 2, color: '#ff5252' }
      }
    ]
  }
}

function renderChart() {
  if (!chart) return
  chart.setOption(buildOption())
}

function handleResize() {
  chart && chart.resize()
}

onMounted(() => {
  if (chartRef.value) {
    chart = echarts.init(chartRef.value)
    chart.setOption(buildOption())
    window.addEventListener('resize', handleResize)
  }
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', handleResize)
  chart && chart.dispose()
  chart = null
})

watch(
  () => props.data,
  () => renderChart(),
  { deep: true }
)
</script>
