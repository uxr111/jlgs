<template>
  <div ref="chartRef" class="chart-box"></div>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount, watch } from 'vue'
import * as echarts from 'echarts'

interface StatusData {
  running: number
  stopped: number
  fault: number
}

const props = defineProps<{
  data: StatusData
}>()

const chartRef = ref<HTMLDivElement | null>(null)
let chart: echarts.ECharts | null = null

function buildOption() {
  const d = props.data || { running: 0, stopped: 0, fault: 0 }
  return {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'item',
      backgroundColor: 'rgba(0,30,60,0.85)',
      borderColor: '#1e90ff',
      textStyle: { color: '#fff' }
    },
    legend: {
      bottom: 5,
      textStyle: { color: '#8db6d8' },
      data: ['运行', '停机', '故障']
    },
    series: [
      {
        name: '设备状态',
        type: 'pie',
        radius: ['45%', '70%'],
        center: ['50%', '45%'],
        avoidLabelOverlap: true,
        label: {
          color: '#cfe8ff',
          formatter: '{b}\n{c}'
        },
        labelLine: { lineStyle: { color: '#8db6d8' } },
        data: [
          { value: d.running, name: '运行', itemStyle: { color: '#00e676' } },
          { value: d.stopped, name: '停机', itemStyle: { color: '#90a4ae' } },
          { value: d.fault, name: '故障', itemStyle: { color: '#ff5252' } }
        ]
      }
    ]
  }
}

function renderChart() {
  if (!chart) return
  chart.setOption(buildOption())
}

function handleResize() {
  chart && chart.resize()
}

onMounted(() => {
  if (chartRef.value) {
    chart = echarts.init(chartRef.value)
    chart.setOption(buildOption())
    window.addEventListener('resize', handleResize)
  }
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', handleResize)
  chart && chart.dispose()
  chart = null
})

watch(
  () => props.data,
  () => renderChart(),
  { deep: true }
)
</script>
