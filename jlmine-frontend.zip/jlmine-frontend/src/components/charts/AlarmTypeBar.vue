<template>
  <div ref="chartRef" class="chart-box"></div>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount, watch } from 'vue'
import * as echarts from 'echarts'
import { alarmTypeText } from '@/utils/format'

interface AlarmTypeData {
  GAS_OVER?: number
  TEMP_HIGH?: number
  DEVICE_FAULT?: number
  [key: string]: number | undefined
}

const props = defineProps<{
  data: AlarmTypeData
}>()

const chartRef = ref<HTMLDivElement | null>(null)
let chart: echarts.ECharts | null = null

function buildOption() {
  const d = props.data || {}
  const keys = Object.keys(d)
  const names = keys.map((k) => alarmTypeText(k))
  const values = keys.map((k) => Number(d[k] || 0))
  return {
    backgroundColor: 'transparent',
    grid: { left: 40, right: 20, top: 20, bottom: 30 },
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      backgroundColor: 'rgba(0,30,60,0.85)',
      borderColor: '#1e90ff',
      textStyle: { color: '#fff' }
    },
    xAxis: {
      type: 'category',
      data: names,
      axisLine: { lineStyle: { color: '#2c5a8a' } },
      axisLabel: { color: '#cfe8ff' }
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#2c5a8a' } },
      axisLabel: { color: '#8db6d8' },
      splitLine: { lineStyle: { color: 'rgba(64,158,255,0.1)' } }
    },
    series: [
      {
        name: '告警数',
        type: 'bar',
        data: values,
        barWidth: 24,
        itemStyle: {
          borderRadius: [4, 4, 0, 0],
          color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
            { offset: 0, color: '#7c4dff' },
            { offset: 1, color: '#ff5252' }
          ])
        },
        label: { show: true, position: 'top', color: '#cfe8ff' }
      }
    ]
  }
}

function renderChart() {
  if (!chart) return
  chart.setOption(buildOption())
}

function handleResize() {
  chart && chart.resize()
}

onMounted(() => {
  if (chartRef.value) {
    chart = echarts.init(chartRef.value)
    chart.setOption(buildOption())
    window.addEventListener('resize', handleResize)
  }
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', handleResize)
  chart && chart.dispose()
  chart = null
})

watch(
  () => props.data,
  () => renderChart(),
  { deep: true }
)
</script>
