<template>
  <div class="screen-layout">
    <router-view />
  </div>
</template>

<script setup lang="ts">
// Screen layout for dashboard
</script>

<style scoped lang="scss">
.screen-layout {
  width: 100vw;
  height: 100vh;
  overflow: hidden;
  background: #050b1f;
}
</style>
