<template>
  <el-container class="app-layout">
    <el-aside width="220px" class="app-aside">
      <div class="logo-box">
        <span class="logo-text">吉林矿山采集监控</span>
      </div>
      <el-menu
        :default-active="activeMenu"
        router
        class="app-menu"
        background-color="#1f2d3d"
        text-color="#bfcbd9"
        active-text-color="#409EFF"
      >
        <el-menu-item index="/screen">
          <el-icon><Monitor /></el-icon>
          <span>监控大屏</span>
        </el-menu-item>
        <el-menu-item index="/mine">
          <el-icon><Location /></el-icon>
          <span>矿区管理</span>
        </el-menu-item>
        <el-menu-item index="/device">
          <el-icon><Cpu /></el-icon>
          <span>设备管理</span>
        </el-menu-item>
        <el-menu-item index="/collection">
          <el-icon><DataLine /></el-icon>
          <span>采集数据</span>
        </el-menu-item>
        <el-menu-item index="/alarm">
          <el-icon><Warning /></el-icon>
          <span>告警列表</span>
        </el-menu-item>
        <el-menu-item index="/vpn">
          <el-icon><Link /></el-icon>
          <span>VPN入口</span>
        </el-menu-item>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header class="app-header">
        <div class="header-title">{{ pageTitle }}</div>
        <div class="header-right">
          <span class="user-info">
            <el-icon><User /></el-icon>
            {{ user.nickname || user.username || '管理员' }}
            <el-tag v-if="user.role" size="small" effect="plain" style="margin-left: 6px">
              {{ user.role }}
            </el-tag>
          </span>
          <el-button type="text" @click="handleLogout">
            <el-icon><SwitchButton /></el-icon>
            退出
          </el-button>
        </div>
      </el-header>
      <el-main class="app-main">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import {
  Monitor,
  Location,
  Cpu,
  DataLine,
  Warning,
  User,
  SwitchButton,
  Link
} from '@element-plus/icons-vue'
import { ElMessageBox } from 'element-plus'
import { useUserStore } from '@/store/user'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const user = computed(() => ({
  nickname: userStore.nickname,
  username: userStore.username,
  role: userStore.role
}))

const activeMenu = computed(() => route.path)
const pageTitle = computed(() => (route.meta?.title as string) || '吉林矿山采集监控')

async function handleLogout() {
  try {
    await ElMessageBox.confirm('确定要退出登录吗？', '提示', {
      type: 'warning',
      confirmButtonText: '确定',
      cancelButtonText: '取消'
    })
  } catch (e) {
    return
  }
  await userStore.logout()
  router.push('/login')
}
</script>

<style scoped lang="scss">
.app-layout {
  height: 100vh;
}
.app-aside {
  background-color: #1f2d3d;
  overflow: hidden;
}
.logo-box {
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 16px;
  font-weight: bold;
  letter-spacing: 1px;
  background: linear-gradient(90deg, #1f2d3d 0%, #2c3e50 100%);
  border-bottom: 1px solid #2b3a4d;
}
.logo-text {
  background: linear-gradient(90deg, #4dd0e1, #409eff);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}
.app-menu {
  border-right: none;
  height: calc(100vh - 60px);
}
.app-header {
  background: #fff;
  border-bottom: 1px solid #e6e6e6;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
  height: 56px;
}
.header-title {
  font-size: 18px;
  font-weight: 600;
  color: #303133;
}
.header-right {
  display: flex;
  align-items: center;
  gap: 16px;
  color: #606266;
}
.user-info {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 14px;
}
.app-main {
  background: #f0f2f5;
  padding: 16px;
  overflow: auto;
}
</style>
