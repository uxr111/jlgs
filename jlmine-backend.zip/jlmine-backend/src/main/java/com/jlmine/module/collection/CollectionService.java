package com.jlmine.module.collection;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jlmine.common.PageResult;
import com.jlmine.module.device.Device;
import com.jlmine.module.device.DeviceMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class CollectionService {

    private final CollectionMapper collectionMapper;
    private final DeviceMapper deviceMapper;

    public PageResult<Map<String, Object>> page(long page, long size, Long deviceId, Long mineId,
                                                LocalDateTime startTime, LocalDateTime endTime) {
        LambdaQueryWrapper<CollectionData> wrapper = new LambdaQueryWrapper<>();
        if (deviceId != null) wrapper.eq(CollectionData::getDeviceId, deviceId);
        if (mineId != null) wrapper.eq(CollectionData::getMineId, mineId);
        if (startTime != null) wrapper.ge(CollectionData::getCollectTime, startTime);
        if (endTime != null) wrapper.le(CollectionData::getCollectTime, endTime);
        wrapper.orderByDesc(CollectionData::getCollectTime);
        Page<CollectionData> pg = collectionMapper.selectPage(new Page<>(page, size), wrapper);
        List<CollectionData> records = pg.getRecords();
        if (records.isEmpty()) {
            return new PageResult<>(0L, page, size, List.of());
        }
        Map<Long, String> deviceNameMap = new HashMap<>();
        for (Long did : records.stream().map(CollectionData::getDeviceId).distinct().toList()) {
            Device d = deviceMapper.selectById(did);
            if (d != null) deviceNameMap.put(did, d.getDeviceName());
        }
        List<Map<String, Object>> list = records.stream().map(c -> toMap(c, deviceNameMap)).toList();
        return new PageResult<>(pg.getTotal(), pg.getCurrent(), pg.getSize(), list);
    }

    public List<Map<String, Object>> latest() {
        List<Device> devices = deviceMapper.selectList(null);
        List<Map<String, Object>> result = new ArrayList<>();
        for (Device d : devices) {
            LambdaQueryWrapper<CollectionData> w = new LambdaQueryWrapper<>();
            w.eq(CollectionData::getDeviceId, d.getId()).orderByDesc(CollectionData::getCollectTime).last("LIMIT 1");
            CollectionData c = collectionMapper.selectOne(w);
            if (c != null) {
                Map<String, Object> item = toMap(c, Map.of(d.getId(), d.getDeviceName()));
                item.put("deviceName", d.getDeviceName());
                item.put("deviceType", d.getDeviceType());
                item.put("mineId", d.getMineId());
                item.put("deviceStatus", d.getStatus());
                result.add(item);
            }
        }
        return result;
    }

    public List<Map<String, Object>> trend(Long mineId, int hours) {
        LocalDateTime from = LocalDateTime.now().minusHours(hours);
        LambdaQueryWrapper<CollectionData> wrapper = new LambdaQueryWrapper<>();
        if (mineId != null) wrapper.eq(CollectionData::getMineId, mineId);
        wrapper.ge(CollectionData::getCollectTime, from);
        wrapper.orderByAsc(CollectionData::getCollectTime);
        List<CollectionData> all = collectionMapper.selectList(wrapper);
        Map<String, Double> hourOutput = new TreeMap<>();
        Map<String, Double> hourTemp = new TreeMap<>();
        Map<String, Double> hourGas = new TreeMap<>();
        Map<String, Integer> hourCount = new TreeMap<>();
        for (CollectionData c : all) {
            String key = c.getCollectTime().toLocalDate().toString() + " " + String.format("%02d", c.getCollectTime().getHour()) + ":00";
            hourOutput.merge(key, c.getOutputTon().doubleValue(), Double::sum);
            hourTemp.merge(key, c.getTemperature().doubleValue(), Double::sum);
            hourGas.merge(key, c.getGasConcentration().doubleValue(), Double::sum);
            hourCount.merge(key, 1, Integer::sum);
        }
        List<Map<String, Object>> result = new ArrayList<>();
        for (String key : hourOutput.keySet()) {
            int cnt = hourCount.getOrDefault(key, 1);
            Map<String, Object> item = new HashMap<>();
            item.put("time", key);
            item.put("output", Math.round(hourOutput.get(key) * 100) / 100.0);
            item.put("temperature", Math.round(hourTemp.get(key) / cnt * 100) / 100.0);
            item.put("gas", Math.round(hourGas.get(key) / cnt * 100) / 100.0);
            result.add(item);
        }
        return result;
    }

    public boolean save(CollectionData data) {
        return collectionMapper.insert(data) > 0;
    }

    private Map<String, Object> toMap(CollectionData c, Map<Long, String> deviceNameMap) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", c.getId());
        m.put("deviceId", c.getDeviceId());
        m.put("deviceName", deviceNameMap.get(c.getDeviceId()));
        m.put("mineId", c.getMineId());
        m.put("outputTon", c.getOutputTon());
        m.put("temperature", c.getTemperature());
        m.put("gasConcentration", c.getGasConcentration());
        m.put("current", c.getCurrent());
        m.put("runStatus", c.getRunStatus());
        m.put("collectTime", c.getCollectTime());
        return m;
    }
}
