package com.jlmine.module.alarm;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jlmine.common.Constants;
import com.jlmine.common.PageResult;
import com.jlmine.module.device.Device;
import com.jlmine.module.device.DeviceMapper;
import com.jlmine.module.mine.Mine;
import com.jlmine.module.mine.MineMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class AlarmService {

    private final AlarmMapper alarmMapper;
    private final DeviceMapper deviceMapper;
    private final MineMapper mineMapper;

    public PageResult<Map<String, Object>> page(long page, long size, Long mineId, String type,
                                                Integer level, Integer status, String keyword) {
        LambdaQueryWrapper<Alarm> wrapper = new LambdaQueryWrapper<>();
        if (mineId != null) wrapper.eq(Alarm::getMineId, mineId);
        if (StringUtils.hasText(type)) wrapper.eq(Alarm::getAlarmType, type);
        if (level != null) wrapper.eq(Alarm::getLevel, level);
        if (status != null) wrapper.eq(Alarm::getStatus, status);
        if (StringUtils.hasText(keyword)) wrapper.like(Alarm::getContent, keyword).or().like(Alarm::getAlarmCode, keyword);
        wrapper.orderByDesc(Alarm::getAlarmTime);
        Page<Alarm> pg = alarmMapper.selectPage(new Page<>(page, size), wrapper);
        List<Alarm> records = pg.getRecords();
        if (records.isEmpty()) {
            return new PageResult<>(0L, page, size, List.of());
        }
        Map<Long, String> deviceNameMap = new HashMap<>();
        Map<Long, String> mineNameMap = new HashMap<>();
        for (Alarm a : records) {
            if (a.getDeviceId() != null && !deviceNameMap.containsKey(a.getDeviceId())) {
                Device d = deviceMapper.selectById(a.getDeviceId());
                if (d != null) deviceNameMap.put(a.getDeviceId(), d.getDeviceName());
            }
            if (a.getMineId() != null && !mineNameMap.containsKey(a.getMineId())) {
                Mine m = mineMapper.selectById(a.getMineId());
                if (m != null) mineNameMap.put(a.getMineId(), m.getMineName());
            }
        }
        List<Map<String, Object>> list = records.stream().map(a -> toMap(a, deviceNameMap, mineNameMap)).toList();
        return new PageResult<>(pg.getTotal(), pg.getCurrent(), pg.getSize(), list);
    }

    public Map<String, Object> getById(Long id) {
        Alarm a = alarmMapper.selectById(id);
        if (a == null) return null;
        Map<Long, String> dm = new HashMap<>();
        Map<Long, String> mm = new HashMap<>();
        if (a.getDeviceId() != null) {
            Device d = deviceMapper.selectById(a.getDeviceId());
            if (d != null) dm.put(d.getId(), d.getDeviceName());
        }
        if (a.getMineId() != null) {
            Mine m = mineMapper.selectById(a.getMineId());
            if (m != null) mm.put(m.getId(), m.getMineName());
        }
        return toMap(a, dm, mm);
    }

    public boolean handle(Long id, String handler, Integer status) {
        Alarm a = alarmMapper.selectById(id);
        if (a == null) return false;
        a.setStatus(status == null ? Constants.ALARM_STATUS_HANDLED : status);
        a.setHandler(handler);
        a.setHandleTime(LocalDateTime.now());
        return alarmMapper.updateById(a) > 0;
    }

    public Map<String, Object> stats() {
        List<Alarm> all = alarmMapper.selectList(null);
        Map<String, Integer> byType = new LinkedHashMap<>();
        Map<String, Integer> byLevel = new LinkedHashMap<>();
        Map<String, Integer> byStatus = new LinkedHashMap<>();
        int unhandled = 0;
        for (Alarm a : all) {
            byType.merge(a.getAlarmType(), 1, Integer::sum);
            byLevel.merge("level_" + a.getLevel(), 1, Integer::sum);
            byStatus.merge("status_" + a.getStatus(), 1, Integer::sum);
            if (a.getStatus() != null && a.getStatus() == 0) unhandled++;
        }
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("total", all.size());
        result.put("unhandled", unhandled);
        result.put("byType", byType);
        result.put("byLevel", byLevel);
        result.put("byStatus", byStatus);
        return result;
    }

    public List<Map<String, Object>> latest(int limit) {
        LambdaQueryWrapper<Alarm> w = new LambdaQueryWrapper<>();
        w.orderByDesc(Alarm::getAlarmTime).last("LIMIT " + limit);
        List<Alarm> records = alarmMapper.selectList(w);
        Map<Long, String> dm = new HashMap<>();
        Map<Long, String> mm = new HashMap<>();
        for (Alarm a : records) {
            if (a.getDeviceId() != null && !dm.containsKey(a.getDeviceId())) {
                Device d = deviceMapper.selectById(a.getDeviceId());
                if (d != null) dm.put(d.getId(), d.getDeviceName());
            }
            if (a.getMineId() != null && !mm.containsKey(a.getMineId())) {
                Mine m = mineMapper.selectById(a.getMineId());
                if (m != null) mm.put(m.getId(), m.getMineName());
            }
        }
        return records.stream().map(a -> toMap(a, dm, mm)).toList();
    }

    private Map<String, Object> toMap(Alarm a, Map<Long, String> deviceNameMap, Map<Long, String> mineNameMap) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", a.getId());
        m.put("alarmCode", a.getAlarmCode());
        m.put("deviceId", a.getDeviceId());
        m.put("deviceName", deviceNameMap.get(a.getDeviceId()));
        m.put("mineId", a.getMineId());
        m.put("mineName", mineNameMap.get(a.getMineId()));
        m.put("alarmType", a.getAlarmType());
        m.put("level", a.getLevel());
        m.put("content", a.getContent());
        m.put("triggerValue", a.getTriggerValue());
        m.put("threshold", a.getThreshold());
        m.put("status", a.getStatus());
        m.put("alarmTime", a.getAlarmTime());
        m.put("handler", a.getHandler());
        m.put("handleTime", a.getHandleTime());
        return m;
    }
}
