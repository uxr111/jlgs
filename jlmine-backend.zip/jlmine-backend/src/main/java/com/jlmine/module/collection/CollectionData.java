package com.jlmine.module.collection;

import com.baomidou.mybatisplus.annotation.TableName;
import com.jlmine.common.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(callSuper = true)
@TableName("collection_data")
public class CollectionData extends BaseEntity {

    private Long deviceId;
    private Long mineId;
    private BigDecimal outputTon;
    private BigDecimal temperature;
    private BigDecimal gasConcentration;
    private BigDecimal current;
    private Integer runStatus;
    private LocalDateTime collectTime;
}
