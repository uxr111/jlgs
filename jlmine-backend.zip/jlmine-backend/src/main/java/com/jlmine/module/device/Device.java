package com.jlmine.module.device;

import com.baomidou.mybatisplus.annotation.TableName;
import com.jlmine.common.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(callSuper = true)
@TableName("device")
public class Device extends BaseEntity {

    private String deviceCode;
    private String deviceName;
    private String deviceType;
    private Long mineId;
    private String model;
    private String location;
    private BigDecimal ratedPower;
    private Integer status;
    private LocalDateTime installTime;
}
