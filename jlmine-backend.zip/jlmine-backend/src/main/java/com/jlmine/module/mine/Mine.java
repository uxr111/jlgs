package com.jlmine.module.mine;

import com.baomidou.mybatisplus.annotation.TableName;
import com.jlmine.common.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

@Data
@EqualsAndHashCode(callSuper = true)
@TableName("mine")
public class Mine extends BaseEntity {

    private String mineCode;
    private String mineName;
    private String region;
    private BigDecimal longitude;
    private BigDecimal latitude;
    private String manager;
    private Integer status;
}
