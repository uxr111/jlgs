package com.jlmine.module.mine;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jlmine.common.PageResult;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MineService {

    private final MineMapper mineMapper;

    public PageResult<Mine> page(long page, long size, String keyword) {
        LambdaQueryWrapper<Mine> wrapper = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            wrapper.like(Mine::getMineName, keyword)
                   .or().like(Mine::getMineCode, keyword)
                   .or().like(Mine::getRegion, keyword);
        }
        wrapper.orderByDesc(Mine::getId);
        Page<Mine> pg = mineMapper.selectPage(new Page<>(page, size), wrapper);
        return new PageResult<>(pg.getTotal(), pg.getCurrent(), pg.getSize(), pg.getRecords());
    }

    public List<Mine> listAll() {
        return mineMapper.selectList(new LambdaQueryWrapper<Mine>().orderByAsc(Mine::getId));
    }

    public Mine getById(Long id) {
        return mineMapper.selectById(id);
    }

    public boolean save(Mine mine) {
        return mineMapper.insert(mine) > 0;
    }

    public boolean update(Mine mine) {
        return mineMapper.updateById(mine) > 0;
    }

    public boolean removeById(Long id) {
        return mineMapper.deleteById(id) > 0;
    }
}
