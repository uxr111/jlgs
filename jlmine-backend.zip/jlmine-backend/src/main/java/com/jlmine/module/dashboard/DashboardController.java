package com.jlmine.module.dashboard;

import com.jlmine.common.R;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Tag(name = "监控大屏")
@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
public class DashboardController {

    private final DashboardService dashboardService;

    @Operation(summary = "总览")
    @GetMapping("/overview")
    public R<Map<String, Object>> overview() {
        return R.ok(dashboardService.overview());
    }

    @Operation(summary = "各矿区产量")
    @GetMapping("/mine-output")
    public R<List<Map<String, Object>>> mineOutput() {
        return R.ok(dashboardService.mineOutput());
    }

    @Operation(summary = "设备状态分布")
    @GetMapping("/device-status")
    public R<Map<String, Object>> deviceStatus() {
        return R.ok(dashboardService.deviceStatus());
    }

    @Operation(summary = "产量趋势")
    @GetMapping("/output-trend")
    public R<List<Map<String, Object>>> outputTrend(@RequestParam(defaultValue = "24") int hours) {
        return R.ok(dashboardService.outputTrend(hours));
    }

    @Operation(summary = "最新告警列表")
    @GetMapping("/alarm-list")
    public R<List<Map<String, Object>>> alarmList(@RequestParam(defaultValue = "10") int limit) {
        return R.ok(dashboardService.alarmList(limit));
    }
}
