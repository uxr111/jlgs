package com.jlmine.module.auth;

import com.jlmine.common.R;
import com.jlmine.module.user.SysUser;
import com.jlmine.module.user.SysUserService;
import com.jlmine.security.JwtUtils;
import com.jlmine.security.SecurityUser;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@Slf4j
@Tag(name = "认证接口")
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtUtils jwtUtils;
    private final SysUserService sysUserService;

    @Operation(summary = "登录")
    @PostMapping("/login")
    public R<LoginResponse> login(@Valid @RequestBody LoginRequest req) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(req.getUsername(), req.getPassword()));
        } catch (BadCredentialsException e) {
            log.warn("登录失败-账号或密码错误: {}", req.getUsername());
            return R.failed(401, "账号或密码错误");
        }
        SysUser user = sysUserService.findByUsername(req.getUsername());
        if (user == null || user.getStatus() == null || user.getStatus() == 0) {
            return R.failed(401, "账号已被禁用");
        }
        String token = jwtUtils.generateToken(user.getId(), user.getUsername(), user.getRole());
        LoginResponse resp = new LoginResponse();
        resp.setToken(token);
        resp.setUsername(user.getUsername());
        resp.setNickname(user.getNickname());
        resp.setRole(user.getRole());
        log.info("用户登录成功: {}", user.getUsername());
        return R.ok(resp);
    }

    @Operation(summary = "当前用户信息")
    @GetMapping("/info")
    public R<LoginResponse> info() {
        var auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !(auth.getPrincipal() instanceof SecurityUser su)) {
            return R.failed(401, "未登录");
        }
        LoginResponse resp = new LoginResponse();
        resp.setUsername(su.getUsername());
        resp.setNickname(su.getNickname());
        resp.setRole(su.getRole());
        return R.ok(resp);
    }

    @Operation(summary = "登出")
    @PostMapping("/logout")
    public R<Void> logout() {
        SecurityContextHolder.clearContext();
        return R.ok();
    }
}
