package com.jlmine.module.collection;

import com.jlmine.common.PageResult;
import com.jlmine.common.R;
import com.jlmine.module.collection.SimulateService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Tag(name = "采集数据")
@RestController
@RequestMapping("/api/collection")
@RequiredArgsConstructor
public class CollectionController {

    private final CollectionService collectionService;
    private final SimulateService simulateService;

    @Operation(summary = "分页查询采集数据")
    @GetMapping("/list")
    public R<PageResult<Map<String, Object>>> list(@RequestParam(defaultValue = "1") long page,
                                                    @RequestParam(defaultValue = "10") long size,
                                                    @RequestParam(required = false) Long deviceId,
                                                    @RequestParam(required = false) Long mineId,
                                                    @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime,
                                                    @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime) {
        return R.ok(collectionService.page(page, size, deviceId, mineId, startTime, endTime));
    }

    @Operation(summary = "各设备最新采集")
    @GetMapping("/latest")
    public R<List<Map<String, Object>>> latest() {
        return R.ok(collectionService.latest());
    }

    @Operation(summary = "产量趋势")
    @GetMapping("/trend")
    public R<List<Map<String, Object>>> trend(@RequestParam(required = false) Long mineId,
                                              @RequestParam(defaultValue = "24") int hours) {
        return R.ok(collectionService.trend(mineId, hours));
    }

    @Operation(summary = "触发一次模拟采集")
    @PostMapping("/simulate")
    public R<Integer> simulate() {
        return R.ok(simulateService.simulate());
    }
}
