package com.jlmine.module.alarm;

import com.jlmine.common.R;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Tag(name = "告警管理")
@RestController
@RequestMapping("/api/alarms")
@RequiredArgsConstructor
public class AlarmController {

    private final AlarmService alarmService;

    @Operation(summary = "分页查询告警")
    @GetMapping
    public R<Map<String, Object>> page(@RequestParam(defaultValue = "1") long page,
                                      @RequestParam(defaultValue = "10") long size,
                                      @RequestParam(required = false) Long mineId,
                                      @RequestParam(required = false) String type,
                                      @RequestParam(required = false) Integer level,
                                      @RequestParam(required = false) Integer status,
                                      @RequestParam(required = false) String keyword) {
        var result = alarmService.page(page, size, mineId, type, level, status, keyword);
        return R.ok(Map.of("total", result.getTotal(), "records", result.getRecords()));
    }

    @Operation(summary = "告警详情")
    @GetMapping("/{id}")
    public R<Map<String, Object>> get(@PathVariable Long id) {
        return R.ok(alarmService.getById(id));
    }

    @Operation(summary = "处理告警")
    @PutMapping("/{id}/handle")
    public R<Boolean> handle(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        String handler = body.get("handler") == null ? "admin" : body.get("handler").toString();
        Integer status = body.get("status") == null ? 1 : Integer.valueOf(body.get("status").toString());
        return R.ok(alarmService.handle(id, handler, status));
    }

    @Operation(summary = "告警统计")
    @GetMapping("/stats")
    public R<Map<String, Object>> stats() {
        return R.ok(alarmService.stats());
    }

    @Operation(summary = "最新告警")
    @GetMapping("/latest")
    public R<List<Map<String, Object>>> latest(@RequestParam(defaultValue = "10") int limit) {
        return R.ok(alarmService.latest(limit));
    }
}
