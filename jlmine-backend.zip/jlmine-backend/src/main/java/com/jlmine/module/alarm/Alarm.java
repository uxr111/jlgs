package com.jlmine.module.alarm;

import com.baomidou.mybatisplus.annotation.TableName;
import com.jlmine.common.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(callSuper = true)
@TableName("alarm")
public class Alarm extends BaseEntity {

    private String alarmCode;
    private Long deviceId;
    private Long mineId;
    private String alarmType;
    private Integer level;
    private String content;
    private BigDecimal triggerValue;
    private BigDecimal threshold;
    private Integer status;
    private LocalDateTime alarmTime;
    private String handler;
    private LocalDateTime handleTime;
}
