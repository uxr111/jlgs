package com.jlmine.module.dashboard;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.jlmine.module.alarm.Alarm;
import com.jlmine.module.alarm.AlarmMapper;
import com.jlmine.module.collection.CollectionData;
import com.jlmine.module.collection.CollectionMapper;
import com.jlmine.module.device.Device;
import com.jlmine.module.device.DeviceMapper;
import com.jlmine.module.mine.Mine;
import com.jlmine.module.mine.MineMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final MineMapper mineMapper;
    private final DeviceMapper deviceMapper;
    private final CollectionMapper collectionMapper;
    private final AlarmMapper alarmMapper;

    public Map<String, Object> overview() {
        long mineCount = mineMapper.selectCount(null);
        long deviceCount = deviceMapper.selectCount(null);
        long onlineDevice = deviceMapper.selectCount(
                new LambdaQueryWrapper<Device>().eq(Device::getStatus, 1));
        LocalDateTime todayStart = LocalDate.now().atStartOfDay();
        List<CollectionData> todayData = collectionMapper.selectList(
                new LambdaQueryWrapper<CollectionData>().ge(CollectionData::getCollectTime, todayStart));
        double todayOutput = todayData.stream()
                .mapToDouble(c -> c.getOutputTon() == null ? 0 : c.getOutputTon().doubleValue())
                .sum();
        long unhandledAlarm = alarmMapper.selectCount(
                new LambdaQueryWrapper<Alarm>().eq(Alarm::getStatus, 0));
        long totalAlarm = alarmMapper.selectCount(null);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("mineCount", mineCount);
        result.put("deviceCount", deviceCount);
        result.put("onlineDevice", onlineDevice);
        result.put("todayOutput", Math.round(todayOutput * 100) / 100.0);
        result.put("unhandledAlarm", unhandledAlarm);
        result.put("totalAlarm", totalAlarm);
        return result;
    }

    public List<Map<String, Object>> mineOutput() {
        List<Mine> mines = mineMapper.selectList(null);
        List<Map<String, Object>> result = new ArrayList<>();
        for (Mine mine : mines) {
            List<CollectionData> list = collectionMapper.selectList(
                    new LambdaQueryWrapper<CollectionData>().eq(CollectionData::getMineId, mine.getId()));
            double output = list.stream()
                    .mapToDouble(c -> c.getOutputTon() == null ? 0 : c.getOutputTon().doubleValue())
                    .sum();
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("mineName", mine.getMineName());
            item.put("output", Math.round(output * 100) / 100.0);
            result.add(item);
        }
        return result;
    }

    public Map<String, Object> deviceStatus() {
        List<Device> devices = deviceMapper.selectList(null);
        long running = devices.stream().filter(d -> d.getStatus() != null && d.getStatus() == 1).count();
        long stopped = devices.stream().filter(d -> d.getStatus() != null && d.getStatus() == 0).count();
        long fault = devices.stream().filter(d -> d.getStatus() != null && d.getStatus() == 2).count();
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("running", running);
        result.put("stopped", stopped);
        result.put("fault", fault);
        return result;
    }

    public List<Map<String, Object>> outputTrend(int hours) {
        LocalDateTime from = LocalDateTime.now().minusHours(hours);
        List<CollectionData> list = collectionMapper.selectList(
                new LambdaQueryWrapper<CollectionData>().ge(CollectionData::getCollectTime, from)
                        .orderByAsc(CollectionData::getCollectTime));
        Map<String, Double> hourOutput = new TreeMap<>();
        Map<String, Double> hourTemp = new TreeMap<>();
        Map<String, Double> hourGas = new TreeMap<>();
        Map<String, Integer> cnt = new HashMap<>();
        for (CollectionData c : list) {
            String key = c.getCollectTime().toLocalDate().toString() + " " +
                    String.format("%02d", c.getCollectTime().getHour()) + ":00";
            hourOutput.merge(key, c.getOutputTon().doubleValue(), Double::sum);
            hourTemp.merge(key, c.getTemperature().doubleValue(), Double::sum);
            hourGas.merge(key, c.getGasConcentration().doubleValue(), Double::sum);
            cnt.merge(key, 1, Integer::sum);
        }
        List<Map<String, Object>> result = new ArrayList<>();
        for (String key : hourOutput.keySet()) {
            int n = cnt.getOrDefault(key, 1);
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("time", key);
            m.put("output", Math.round(hourOutput.get(key) * 100) / 100.0);
            m.put("temperature", Math.round(hourTemp.get(key) / n * 100) / 100.0);
            m.put("gas", Math.round(hourGas.get(key) / n * 100) / 100.0);
            result.add(m);
        }
        return result;
    }

    public List<Map<String, Object>> alarmList(int limit) {
        List<Alarm> alarms = alarmMapper.selectList(
                new LambdaQueryWrapper<Alarm>().orderByDesc(Alarm::getAlarmTime).last("LIMIT " + limit));
        List<Map<String, Object>> result = new ArrayList<>();
        for (Alarm a : alarms) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", a.getId());
            m.put("alarmCode", a.getAlarmCode());
            m.put("alarmType", a.getAlarmType());
            m.put("level", a.getLevel());
            m.put("content", a.getContent());
            m.put("status", a.getStatus());
            m.put("alarmTime", a.getAlarmTime());
            Device d = a.getDeviceId() == null ? null : deviceMapper.selectById(a.getDeviceId());
            m.put("deviceName", d == null ? null : d.getDeviceName());
            result.add(m);
        }
        return result;
    }
}
