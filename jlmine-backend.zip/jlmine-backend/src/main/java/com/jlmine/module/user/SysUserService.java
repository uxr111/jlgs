package com.jlmine.module.user;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import org.springframework.stereotype.Service;

@Service
public class SysUserService {

    private final SysUserMapper sysUserMapper;

    public SysUserService(SysUserMapper sysUserMapper) {
        this.sysUserMapper = sysUserMapper;
    }

    public SysUser findByUsername(String username) {
        return sysUserMapper.selectOne(
                new LambdaQueryWrapper<SysUser>().eq(SysUser::getUsername, username));
    }

    public SysUser getById(Long id) {
        return sysUserMapper.selectById(id);
    }

    public boolean saveOrUpdate(SysUser user) {
        if (user.getId() == null) {
            return sysUserMapper.insert(user) > 0;
        }
        return sysUserMapper.updateById(user) > 0;
    }
}
