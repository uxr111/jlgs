package com.jlmine.module.mine;

import com.jlmine.common.PageResult;
import com.jlmine.common.R;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "矿区管理")
@RestController
@RequestMapping("/api/mines")
@RequiredArgsConstructor
public class MineController {

    private final MineService mineService;

    @Operation(summary = "分页查询矿区")
    @GetMapping
    public R<PageResult<Mine>> page(@RequestParam(defaultValue = "1") long page,
                                   @RequestParam(defaultValue = "10") long size,
                                   @RequestParam(required = false) String keyword) {
        return R.ok(mineService.page(page, size, keyword));
    }

    @Operation(summary = "全部矿区")
    @GetMapping("/all")
    public R<List<Mine>> all() {
        return R.ok(mineService.listAll());
    }

    @Operation(summary = "矿区详情")
    @GetMapping("/{id}")
    public R<Mine> get(@PathVariable Long id) {
        return R.ok(mineService.getById(id));
    }

    @Operation(summary = "新增矿区")
    @PostMapping
    public R<Boolean> save(@RequestBody Mine mine) {
        return R.ok(mineService.save(mine));
    }

    @Operation(summary = "修改矿区")
    @PutMapping("/{id}")
    public R<Boolean> update(@PathVariable Long id, @RequestBody Mine mine) {
        mine.setId(id);
        return R.ok(mineService.update(mine));
    }

    @Operation(summary = "删除矿区")
    @DeleteMapping("/{id}")
    public R<Boolean> delete(@PathVariable Long id) {
        return R.ok(mineService.removeById(id));
    }
}
