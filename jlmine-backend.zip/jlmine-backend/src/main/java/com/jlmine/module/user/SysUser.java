package com.jlmine.module.user;

import com.baomidou.mybatisplus.annotation.TableName;
import com.jlmine.common.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@TableName("sys_user")
public class SysUser extends BaseEntity {

    private String username;
    private String password;
    private String nickname;
    private String role;
    private Integer status;
}
