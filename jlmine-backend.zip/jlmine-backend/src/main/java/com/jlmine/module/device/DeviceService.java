package com.jlmine.module.device;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jlmine.common.PageResult;
import com.jlmine.module.mine.Mine;
import com.jlmine.module.mine.MineMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class DeviceService {

    private final DeviceMapper deviceMapper;
    private final MineMapper mineMapper;

    public PageResult<Map<String, Object>> page(long page, long size, Long mineId, String type, String keyword) {
        LambdaQueryWrapper<Device> wrapper = new LambdaQueryWrapper<>();
        if (mineId != null) {
            wrapper.eq(Device::getMineId, mineId);
        }
        if (StringUtils.hasText(type)) {
            wrapper.eq(Device::getDeviceType, type);
        }
        if (StringUtils.hasText(keyword)) {
            wrapper.like(Device::getDeviceName, keyword)
                   .or().like(Device::getDeviceCode, keyword);
        }
        wrapper.orderByDesc(Device::getId);
        Page<Device> pg = deviceMapper.selectPage(new Page<>(page, size), wrapper);
        List<Device> records = pg.getRecords();
        if (records.isEmpty()) {
            return new PageResult<>(0L, page, size, List.of());
        }
        List<Long> mineIds = records.stream().map(Device::getMineId).distinct().toList();
        Map<Long, String> mineNameMap = new HashMap<>();
        for (Long mid : mineIds) {
            Mine m = mineMapper.selectById(mid);
            if (m != null) mineNameMap.put(mid, m.getMineName());
        }
        List<Map<String, Object>> list = records.stream().map(d -> {
            Map<String, Object> item = new HashMap<>();
            item.put("id", d.getId());
            item.put("deviceCode", d.getDeviceCode());
            item.put("deviceName", d.getDeviceName());
            item.put("deviceType", d.getDeviceType());
            item.put("mineId", d.getMineId());
            item.put("mineName", mineNameMap.get(d.getMineId()));
            item.put("model", d.getModel());
            item.put("location", d.getLocation());
            item.put("ratedPower", d.getRatedPower());
            item.put("status", d.getStatus());
            item.put("installTime", d.getInstallTime());
            item.put("createTime", d.getCreateTime());
            return item;
        }).toList();
        return new PageResult<>(pg.getTotal(), pg.getCurrent(), pg.getSize(), list);
    }

    public List<Device> listAll() {
        return deviceMapper.selectList(new LambdaQueryWrapper<Device>().orderByAsc(Device::getId));
    }

    public List<Device> listByMineId(Long mineId) {
        return deviceMapper.selectList(new LambdaQueryWrapper<Device>().eq(Device::getMineId, mineId));
    }

    public Device getById(Long id) {
        return deviceMapper.selectById(id);
    }

    public boolean save(Device device) {
        if (device.getStatus() == null) device.setStatus(1);
        return deviceMapper.insert(device) > 0;
    }

    public boolean update(Device device) {
        return deviceMapper.updateById(device) > 0;
    }

    public boolean removeById(Long id) {
        return deviceMapper.deleteById(id) > 0;
    }
}
