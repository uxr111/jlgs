package com.jlmine.module.device;

import com.jlmine.common.PageResult;
import com.jlmine.common.R;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Tag(name = "设备管理")
@RestController
@RequestMapping("/api/devices")
@RequiredArgsConstructor
public class DeviceController {

    private final DeviceService deviceService;

    @Operation(summary = "分页查询设备")
    @GetMapping
    public R<PageResult<Map<String, Object>>> page(@RequestParam(defaultValue = "1") long page,
                                                   @RequestParam(defaultValue = "10") long size,
                                                   @RequestParam(required = false) Long mineId,
                                                   @RequestParam(required = false) String type,
                                                   @RequestParam(required = false) String keyword) {
        return R.ok(deviceService.page(page, size, mineId, type, keyword));
    }

    @Operation(summary = "全部设备")
    @GetMapping("/all")
    public R<List<Device>> all() {
        return R.ok(deviceService.listAll());
    }

    @Operation(summary = "按矿区查询设备")
    @GetMapping("/mine/{mineId}")
    public R<List<Device>> byMine(@PathVariable Long mineId) {
        return R.ok(deviceService.listByMineId(mineId));
    }

    @Operation(summary = "设备详情")
    @GetMapping("/{id}")
    public R<Device> get(@PathVariable Long id) {
        return R.ok(deviceService.getById(id));
    }

    @Operation(summary = "新增设备")
    @PostMapping
    public R<Boolean> save(@RequestBody Device device) {
        return R.ok(deviceService.save(device));
    }

    @Operation(summary = "修改设备")
    @PutMapping("/{id}")
    public R<Boolean> update(@PathVariable Long id, @RequestBody Device device) {
        device.setId(id);
        return R.ok(deviceService.update(device));
    }

    @Operation(summary = "删除设备")
    @DeleteMapping("/{id}")
    public R<Boolean> delete(@PathVariable Long id) {
        return R.ok(deviceService.removeById(id));
    }
}
