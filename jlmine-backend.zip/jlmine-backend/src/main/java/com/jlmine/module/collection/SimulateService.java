package com.jlmine.module.collection;

import com.jlmine.common.Constants;
import com.jlmine.module.alarm.Alarm;
import com.jlmine.module.alarm.AlarmMapper;
import com.jlmine.module.device.Device;
import com.jlmine.module.device.DeviceMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

@Slf4j
@Service
@RequiredArgsConstructor
public class SimulateService {

    private final DeviceMapper deviceMapper;
    private final CollectionMapper collectionMapper;
    private final AlarmMapper alarmMapper;
    private final Random random = new Random();

    /**
     * 每 30 秒自动模拟一次采集
     */
    @Scheduled(fixedDelay = 30000, initialDelay = 15000)
    public void scheduledSimulate() {
        int count = simulate();
        log.info("定时模拟采集完成，本次新增 {} 条采集记录", count);
    }

    /**
     * 执行一次模拟采集，返回新增采集记录数
     */
    public int simulate() {
        List<Device> devices = deviceMapper.selectList(null);
        int collected = 0;
        for (Device d : devices) {
            if (d.getStatus() != null && d.getStatus() == Constants.DEVICE_STATUS_STOPPED) {
                continue;
            }
            CollectionData data = generateData(d);
            collectionMapper.insert(data);
            collected++;
            checkAndCreateAlarm(d, data);
        }
        return collected;
    }

    private CollectionData generateData(Device d) {
        CollectionData data = new CollectionData();
        data.setDeviceId(d.getId());
        data.setMineId(d.getMineId());
        data.setCollectTime(LocalDateTime.now());
        data.setRunStatus(1);

        double gas, temp, output, current;
        switch (d.getDeviceType()) {
            case Constants.DEVICE_SHEARER:
                output = round2(150 + random.nextDouble() * 200);
                temp = round2(25 + random.nextDouble() * 22);
                gas = round2(0.2 + random.nextDouble() * 1.1);
                current = round2(50 + random.nextDouble() * 40);
                break;
            case Constants.DEVICE_BELT:
                output = round2(120 + random.nextDouble() * 220);
                temp = round2(20 + random.nextDouble() * 15);
                gas = round2(0.2 + random.nextDouble() * 0.7);
                current = round2(35 + random.nextDouble() * 25);
                break;
            case Constants.DEVICE_VENTILATOR:
                output = 0.0;
                temp = round2(20 + random.nextDouble() * 12);
                gas = round2(0.1 + random.nextDouble() * 0.4);
                current = round2(15 + random.nextDouble() * 12);
                break;
            case Constants.DEVICE_GAS_DETECTOR:
                output = 0.0;
                temp = round2(25 + random.nextDouble() * 12);
                gas = round2(0.3 + random.nextDouble() * 1.0);
                current = round2(0.05 + random.nextDouble() * 0.1);
                break;
            case Constants.DEVICE_HOIST:
                output = 0.0;
                temp = round2(22 + random.nextDouble() * 16);
                gas = round2(0.2 + random.nextDouble() * 0.4);
                current = round2(30 + random.nextDouble() * 25);
                break;
            default:
                output = round2(random.nextDouble() * 100);
                temp = round2(20 + random.nextDouble() * 20);
                gas = round2(0.2 + random.nextDouble() * 0.8);
                current = round2(20 + random.nextDouble() * 20);
        }
        data.setOutputTon(BigDecimal.valueOf(output));
        data.setTemperature(BigDecimal.valueOf(temp));
        data.setGasConcentration(BigDecimal.valueOf(gas));
        data.setCurrent(BigDecimal.valueOf(current));
        return data;
    }

    private void checkAndCreateAlarm(Device d, CollectionData data) {
        double gas = data.getGasConcentration().doubleValue();
        double temp = data.getTemperature().doubleValue();
        double current = data.getCurrent().doubleValue();
        double rated = d.getRatedPower() == null ? 0 : d.getRatedPower().doubleValue();

        if (gas >= Constants.THRESHOLD_GAS) {
            createAlarm(d, Constants.ALARM_GAS_OVER, Constants.ALARM_LEVEL_HIGH,
                    d.getDeviceName() + " 检测到瓦斯浓度 " + gas + "%，超过阈值 " + Constants.THRESHOLD_GAS + "%",
                    gas, Constants.THRESHOLD_GAS);
        }
        if (temp >= Constants.THRESHOLD_TEMP) {
            createAlarm(d, Constants.ALARM_TEMP_HIGH, Constants.ALARM_LEVEL_MEDIUM,
                    d.getDeviceName() + " 温度 " + temp + "℃，超过阈值 " + Constants.THRESHOLD_TEMP + "℃",
                    temp, Constants.THRESHOLD_TEMP);
        }
        if (rated > 0 && current > rated * 0.18 * Constants.THRESHOLD_CURRENT_RATIO) {
            createAlarm(d, Constants.ALARM_DEVICE_FAULT, Constants.ALARM_LEVEL_MEDIUM,
                    d.getDeviceName() + " 电流 " + current + "A 超过额定 " + (rated * 0.18) + "A 的 1.2 倍",
                    current, rated * 0.18 * Constants.THRESHOLD_CURRENT_RATIO);
        }
        if (ThreadLocalRandom.current().nextInt(100) < 3) {
            createAlarm(d, Constants.ALARM_DEVICE_FAULT, Constants.ALARM_LEVEL_MEDIUM,
                    d.getDeviceName() + " 设备状态异常，疑似故障",
                    0.0, 0.0);
        }
    }

    private void createAlarm(Device d, String type, int level, String content, double triggerVal, double threshold) {
        Alarm alarm = new Alarm();
        alarm.setAlarmCode("ALM-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + "-" + (1000 + random.nextInt(9000)));
        alarm.setDeviceId(d.getId());
        alarm.setMineId(d.getMineId());
        alarm.setAlarmType(type);
        alarm.setLevel(level);
        alarm.setContent(content);
        alarm.setTriggerValue(BigDecimal.valueOf(round2(triggerVal)));
        alarm.setThreshold(BigDecimal.valueOf(round2(threshold)));
        alarm.setStatus(Constants.ALARM_STATUS_UNHANDLED);
        alarm.setAlarmTime(LocalDateTime.now());
        alarmMapper.insert(alarm);
        log.warn("生成告警: [{}] {}", type, content);
    }

    private double round2(double v) {
        return BigDecimal.valueOf(v).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }
}
