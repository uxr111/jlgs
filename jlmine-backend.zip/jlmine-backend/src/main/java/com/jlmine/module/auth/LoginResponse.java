package com.jlmine.module.auth;

import lombok.Data;

@Data
public class LoginResponse {
    private String token;
    private String tokenHead = "Bearer ";
    private String username;
    private String nickname;
    private String role;
}
