package com.jlmine.module.mine;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MineMapper extends BaseMapper<Mine> {
}
