package com.jlmine.common;

public final class Constants {

    private Constants() {
    }

    /** 默认管理员账号 */
    public static final String DEFAULT_ADMIN_USERNAME = "admin";
    /** 默认管理员密码（明文写在项目中，入库时 BCrypt 加密） */
    public static final String DEFAULT_ADMIN_PASSWORD = "Mjj@123456";
    /** 默认管理员昵称 */
    public static final String DEFAULT_ADMIN_NICKNAME = "系统管理员";
    /** 默认角色 */
    public static final String DEFAULT_ROLE = "ROLE_ADMIN";

    /** 设备类型 */
    public static final String DEVICE_SHEARER = "SHEARER";
    public static final String DEVICE_BELT = "BELT";
    public static final String DEVICE_VENTILATOR = "VENTILATOR";
    public static final String DEVICE_GAS_DETECTOR = "GAS_DETECTOR";
    public static final String DEVICE_HOIST = "HOIST";

    /** 设备状态 */
    public static final int DEVICE_STATUS_RUNNING = 1;
    public static final int DEVICE_STATUS_STOPPED = 0;
    public static final int DEVICE_STATUS_FAULT = 2;

    /** 告警类型 */
    public static final String ALARM_GAS_OVER = "GAS_OVER";
    public static final String ALARM_TEMP_HIGH = "TEMP_HIGH";
    public static final String ALARM_DEVICE_FAULT = "DEVICE_FAULT";

    /** 告警级别 */
    public static final int ALARM_LEVEL_LOW = 1;
    public static final int ALARM_LEVEL_MEDIUM = 2;
    public static final int ALARM_LEVEL_HIGH = 3;

    /** 告警状态 */
    public static final int ALARM_STATUS_UNHANDLED = 0;
    public static final int ALARM_STATUS_HANDLED = 1;
    public static final int ALARM_STATUS_IGNORED = 2;

    /** 阈值 */
    public static final double THRESHOLD_GAS = 1.0;
    public static final double THRESHOLD_TEMP = 40.0;
    public static final double THRESHOLD_CURRENT_RATIO = 1.2;

    /** Authorization 头前缀 */
    public static final String AUTH_HEADER = "Authorization";
    public static final String AUTH_PREFIX = "Bearer ";
}
