package com.jlmine.init;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.jlmine.common.Constants;
import com.jlmine.module.user.SysUser;
import com.jlmine.module.user.SysUserMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * 初始化默认管理员账号 admin / Mjj@123456
 * 密码以明文形式写在 Constants.DEFAULT_ADMIN_PASSWORD（即 "Mjj@123456"），
 * 入库时使用 BCrypt 加密，避免硬编码 hash 因 encoder 配置差异导致无法登录。
 */
@Slf4j
@Component
@Order(1)
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final SysUserMapper sysUserMapper;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        String username = Constants.DEFAULT_ADMIN_USERNAME;
        String rawPassword = Constants.DEFAULT_ADMIN_PASSWORD;

        SysUser existing = sysUserMapper.selectOne(
                new LambdaQueryWrapper<SysUser>().eq(SysUser::getUsername, username));

        String encoded = passwordEncoder.encode(rawPassword);

        if (existing == null) {
            SysUser admin = new SysUser();
            admin.setUsername(username);
            admin.setPassword(encoded);
            admin.setNickname(Constants.DEFAULT_ADMIN_NICKNAME);
            admin.setRole(Constants.DEFAULT_ROLE);
            admin.setStatus(1);
            admin.setCreateTime(LocalDateTime.now());
            admin.setUpdateTime(LocalDateTime.now());
            sysUserMapper.insert(admin);
            log.info("初始化管理员账号完成: {} / {}", username, rawPassword);
        } else {
            existing.setPassword(encoded);
            existing.setNickname(Constants.DEFAULT_ADMIN_NICKNAME);
            existing.setRole(Constants.DEFAULT_ROLE);
            existing.setStatus(1);
            existing.setUpdateTime(LocalDateTime.now());
            sysUserMapper.updateById(existing);
            log.info("已重置管理员账号密码: {} / {}", username, rawPassword);
        }
    }
}
