package com.jlmine;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@MapperScan("com.jlmine")
@EnableScheduling
public class JlMineApplication {

    public static void main(String[] args) {
        SpringApplication.run(JlMineApplication.class, args);
        System.out.println("\n========================================");
        System.out.println("  吉林矿山采集监控 - 后端启动成功");
        System.out.println("  访问: http://localhost:9090");
        System.out.println("  Swagger: http://localhost:9090/swagger-ui/index.html");
        System.out.println("  H2控制台: http://localhost:9090/h2-console");
        System.out.println("  默认账号: admin / Mjj@123456");
        System.out.println("========================================\n");
    }
}
