-- ============================================
-- 吉林矿山采集监控 - 建表脚本 (H2 内存模式, MODE=MySQL)
-- ============================================

DROP TABLE IF EXISTS sys_user;
DROP TABLE IF EXISTS mine;
DROP TABLE IF EXISTS device;
DROP TABLE IF EXISTS collection_data;
DROP TABLE IF EXISTS alarm;

-- 用户表
CREATE TABLE sys_user (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(100) NOT NULL,
  nickname VARCHAR(50),
  role VARCHAR(20) DEFAULT 'ROLE_ADMIN',
  status TINYINT DEFAULT 1,
  create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX uk_sys_user_username ON sys_user(username);

-- 矿区表
CREATE TABLE mine (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  mine_code VARCHAR(20) NOT NULL,
  mine_name VARCHAR(50) NOT NULL,
  region VARCHAR(50),
  longitude DECIMAL(10,6),
  latitude DECIMAL(10,6),
  manager VARCHAR(50),
  status TINYINT DEFAULT 1,
  create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX uk_mine_code ON mine(mine_code);

-- 设备表
CREATE TABLE device (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  device_code VARCHAR(20) NOT NULL,
  device_name VARCHAR(50) NOT NULL,
  device_type VARCHAR(20) NOT NULL,
  mine_id BIGINT NOT NULL,
  model VARCHAR(50),
  location VARCHAR(100),
  rated_power DECIMAL(10,2),
  status TINYINT DEFAULT 1,
  install_time TIMESTAMP,
  create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX uk_device_code ON device(device_code);
CREATE INDEX idx_device_mine ON device(mine_id);

-- 采集数据表
CREATE TABLE collection_data (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  device_id BIGINT NOT NULL,
  mine_id BIGINT NOT NULL,
  output_ton DECIMAL(10,2),
  temperature DECIMAL(5,2),
  gas_concentration DECIMAL(5,2),
  current DECIMAL(8,2),
  run_status TINYINT,
  collect_time TIMESTAMP NOT NULL,
  create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_cd_device_time ON collection_data(device_id, collect_time);
CREATE INDEX idx_cd_mine_time ON collection_data(mine_id, collect_time);

-- 告警表
CREATE TABLE alarm (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  alarm_code VARCHAR(50),
  device_id BIGINT,
  mine_id BIGINT,
  alarm_type VARCHAR(20) NOT NULL,
  level TINYINT DEFAULT 2,
  content VARCHAR(500),
  trigger_value DECIMAL(10,2),
  threshold DECIMAL(10,2),
  status TINYINT DEFAULT 0,
  alarm_time TIMESTAMP NOT NULL,
  handler VARCHAR(50),
  handle_time TIMESTAMP,
  create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_alarm_mine_time ON alarm(mine_id, alarm_time);
CREATE INDEX idx_alarm_status ON alarm(status);
