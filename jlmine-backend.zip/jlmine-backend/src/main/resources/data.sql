-- ============================================
-- 吉林矿山采集监控 - 种子数据
-- 说明：admin 用户由 DataInitializer 运行时 BCrypt 加密写入，此处不插
-- 时间使用 CURRENT_TIMESTAMP - INTERVAL 表达式，保证每次启动都是"近24h"数据
-- ============================================

-- ---------- 5 个矿区 ----------
INSERT INTO mine (mine_code, mine_name, region, longitude, latitude, manager, status) VALUES
('CC001', '长春矿区', '长春市', 125.324500, 43.886800, '王志强', 1),
('JL001', '吉林矿区', '吉林市', 126.549500, 43.837800, '李建国', 1),
('BS001', '白山矿区', '白山市', 126.427600, 41.942200, '张伟', 1),
('TH001', '通化矿区', '通化市', 125.950200, 41.721000, '刘洋', 1),
('YB001', '延边矿区', '延边朝鲜族自治州', 129.509900, 42.891400, '陈磊', 1);

-- ---------- 15 台设备（每矿 3 台，覆盖 5 种类型） ----------
-- 长春矿区
INSERT INTO device (device_code, device_name, device_type, mine_id, model, location, rated_power, status, install_time) VALUES
('CC-SHR-01', '长春1号采煤机', 'SHEARER', 1, 'MG500/1180-WD', 'A区工作面', 1180.00, 1, '2023-06-15 10:00:00'),
('CC-BLT-01', '长春1号运输皮带', 'BELT', 1, 'DSJ100/80/45', '主运输巷', 250.00, 1, '2023-05-20 09:00:00'),
('CC-VENT-01', '长春1号通风机', 'VENTILATOR', 1, 'FBCDZ-8-No24', '主井通风', 220.00, 1, '2023-04-10 14:00:00');
-- 吉林矿区
INSERT INTO device (device_code, device_name, device_type, mine_id, model, location, rated_power, status, install_time) VALUES
('JL-SHR-01', '吉林1号采煤机', 'SHEARER', 2, 'MG300/700-WD', 'B区工作面', 700.00, 1, '2023-07-01 10:00:00'),
('JL-GAS-01', '吉林1号瓦斯检测仪', 'GAS_DETECTOR', 2, 'GJG100H', 'B区回风巷', 0.50, 1, '2023-06-25 11:00:00'),
('JL-HST-01', '吉林1号提升机', 'HOIST', 2, 'JK-2.5/20E', '主井提升', 560.00, 1, '2023-03-15 15:00:00');
-- 白山矿区
INSERT INTO device (device_code, device_name, device_type, mine_id, model, location, rated_power, status, install_time) VALUES
('BS-SHR-01', '白山1号采煤机', 'SHEARER', 3, 'MG500/1180-WD', 'C区工作面', 1180.00, 1, '2023-08-01 10:00:00'),
('BS-BLT-01', '白山1号运输皮带', 'BELT', 3, 'DSJ120/100/55', '主运输巷', 300.00, 1, '2023-07-20 09:00:00'),
('BS-GAS-01', '白山1号瓦斯检测仪', 'GAS_DETECTOR', 3, 'GJG100H', 'C区回风巷', 0.50, 1, '2023-06-25 11:00:00');
-- 通化矿区
INSERT INTO device (device_code, device_name, device_type, mine_id, model, location, rated_power, status, install_time) VALUES
('TH-SHR-01', '通化1号采煤机', 'SHEARER', 4, 'MG300/700-WD', 'D区工作面', 700.00, 1, '2023-09-01 10:00:00'),
('TH-VENT-01', '通化1号通风机', 'VENTILATOR', 4, 'FBCDZ-8-No22', '副井通风', 185.00, 1, '2023-08-15 14:00:00'),
('TH-HST-01', '通化1号提升机', 'HOIST', 4, 'JK-2/20E', '副井提升', 450.00, 0, '2023-04-20 15:00:00');
-- 延边矿区
INSERT INTO device (device_code, device_name, device_type, mine_id, model, location, rated_power, status, install_time) VALUES
('YB-SHR-01', '延边1号采煤机', 'SHEARER', 5, 'MG500/1180-WD', 'E区工作面', 1180.00, 1, '2023-10-01 10:00:00'),
('YB-BLT-01', '延边1号运输皮带', 'BELT', 5, 'DSJ100/80/45', '主运输巷', 250.00, 1, '2023-09-20 09:00:00'),
('YB-GAS-01', '延边1号瓦斯检测仪', 'GAS_DETECTOR', 5, 'GJG100H', 'E区回风巷', 0.50, 1, '2023-08-25 11:00:00');

-- ---------- 历史采集数据（每台设备 2 条，共 30 条，分布在近 24h） ----------
-- 长春
INSERT INTO collection_data (device_id, mine_id, output_ton, temperature, gas_concentration, current, run_status, collect_time) VALUES
(1, 1, 285.50, 32.50, 0.45, 65.20, 1, CURRENT_TIMESTAMP - INTERVAL '23' HOUR),
(1, 1, 312.80, 35.20, 0.52, 72.10, 1, CURRENT_TIMESTAMP - INTERVAL '1' HOUR),
(2, 1, 285.50, 28.30, 0.38, 48.50, 1, CURRENT_TIMESTAMP - INTERVAL '22' HOUR),
(2, 1, 308.00, 30.10, 0.41, 52.30, 1, CURRENT_TIMESTAMP - INTERVAL '55' MINUTE),
(3, 1, 0.00, 25.00, 0.20, 18.50, 1, CURRENT_TIMESTAMP - INTERVAL '21' HOUR),
(3, 1, 0.00, 26.50, 0.25, 19.20, 1, CURRENT_TIMESTAMP - INTERVAL '50' MINUTE);
-- 吉林
INSERT INTO collection_data (device_id, mine_id, output_ton, temperature, gas_concentration, current, run_status, collect_time) VALUES
(4, 2, 198.30, 30.80, 0.50, 42.10, 1, CURRENT_TIMESTAMP - INTERVAL '20' HOUR),
(4, 2, 225.60, 33.40, 0.58, 45.80, 1, CURRENT_TIMESTAMP - INTERVAL '48' MINUTE),
(5, 2, 0.00, 27.00, 1.25, 0.12, 1, CURRENT_TIMESTAMP - INTERVAL '19' HOUR),
(5, 2, 0.00, 28.20, 0.85, 0.10, 1, CURRENT_TIMESTAMP - INTERVAL '45' MINUTE),
(6, 2, 0.00, 24.00, 0.30, 35.20, 1, CURRENT_TIMESTAMP - INTERVAL '18' HOUR),
(6, 2, 0.00, 25.50, 0.32, 36.10, 1, CURRENT_TIMESTAMP - INTERVAL '42' MINUTE);
-- 白山
INSERT INTO collection_data (device_id, mine_id, output_ton, temperature, gas_concentration, current, run_status, collect_time) VALUES
(7, 3, 302.40, 34.60, 0.48, 68.50, 1, CURRENT_TIMESTAMP - INTERVAL '17' HOUR),
(7, 3, 288.90, 36.20, 0.55, 66.20, 1, CURRENT_TIMESTAMP - INTERVAL '40' MINUTE),
(8, 3, 295.00, 29.50, 0.42, 50.10, 1, CURRENT_TIMESTAMP - INTERVAL '16' HOUR),
(8, 3, 310.50, 31.20, 0.46, 54.30, 1, CURRENT_TIMESTAMP - INTERVAL '38' MINUTE),
(9, 3, 0.00, 28.50, 0.92, 0.11, 1, CURRENT_TIMESTAMP - INTERVAL '15' HOUR),
(9, 3, 0.00, 29.80, 1.05, 0.12, 1, CURRENT_TIMESTAMP - INTERVAL '35' MINUTE);
-- 通化
INSERT INTO collection_data (device_id, mine_id, output_ton, temperature, gas_concentration, current, run_status, collect_time) VALUES
(10, 4, 185.20, 31.50, 0.52, 40.50, 1, CURRENT_TIMESTAMP - INTERVAL '14' HOUR),
(10, 4, 168.70, 33.80, 0.60, 38.20, 1, CURRENT_TIMESTAMP - INTERVAL '33' MINUTE),
(11, 4, 0.00, 26.00, 0.22, 16.80, 1, CURRENT_TIMESTAMP - INTERVAL '13' HOUR),
(11, 4, 0.00, 27.20, 0.28, 17.50, 1, CURRENT_TIMESTAMP - INTERVAL '30' MINUTE),
(12, 4, 0.00, 23.00, 0.31, 0.00, 0, CURRENT_TIMESTAMP - INTERVAL '12' HOUR),
(12, 4, 0.00, 23.50, 0.30, 0.00, 0, CURRENT_TIMESTAMP - INTERVAL '28' MINUTE);
-- 延边
INSERT INTO collection_data (device_id, mine_id, output_ton, temperature, gas_concentration, current, run_status, collect_time) VALUES
(13, 5, 278.60, 33.20, 0.46, 63.50, 1, CURRENT_TIMESTAMP - INTERVAL '11' HOUR),
(13, 5, 295.40, 35.80, 0.54, 67.20, 1, CURRENT_TIMESTAMP - INTERVAL '25' MINUTE),
(14, 5, 278.60, 29.00, 0.40, 49.50, 1, CURRENT_TIMESTAMP - INTERVAL '10' HOUR),
(14, 5, 290.20, 30.50, 0.43, 51.80, 1, CURRENT_TIMESTAMP - INTERVAL '22' MINUTE),
(15, 5, 0.00, 28.00, 0.88, 0.11, 1, CURRENT_TIMESTAMP - INTERVAL '9' HOUR),
(15, 5, 0.00, 29.20, 1.10, 0.12, 1, CURRENT_TIMESTAMP - INTERVAL '20' MINUTE);

-- ---------- 历史告警（10 条，覆盖三种类型与三级） ----------
INSERT INTO alarm (alarm_code, device_id, mine_id, alarm_type, level, content, trigger_value, threshold, status, alarm_time, handler, handle_time) VALUES
('ALM-20260928-001', 5,  2, 'GAS_OVER',     3, '吉林矿区瓦斯检测仪检测到瓦斯浓度1.25%，超过阈值1.0%',                1.25, 1.00, 1, CURRENT_TIMESTAMP - INTERVAL '19' HOUR, 'admin', CURRENT_TIMESTAMP - INTERVAL '18' HOUR),
('ALM-20260928-002', 7,  3, 'TEMP_HIGH',    2, '白山矿区1号采煤机温度36.2℃，接近阈值40℃',                          36.20, 40.00, 2, CURRENT_TIMESTAMP - INTERVAL '17' HOUR, 'admin', CURRENT_TIMESTAMP - INTERVAL '16' HOUR),
('ALM-20260928-003', 9,  3, 'GAS_OVER',     3, '白山矿区瓦斯检测仪检测到瓦斯浓度1.05%，超过阈值1.0%',                1.05, 1.00, 0, CURRENT_TIMESTAMP - INTERVAL '15' HOUR, NULL, NULL),
('ALM-20260928-004', 12, 4, 'DEVICE_FAULT', 2, '通化矿区1号提升机停机，设备状态异常',                                    0.00, 0.00, 1, CURRENT_TIMESTAMP - INTERVAL '12' HOUR, 'admin', CURRENT_TIMESTAMP - INTERVAL '11' HOUR),
('ALM-20260928-005', 15, 5, 'GAS_OVER',     3, '延边矿区瓦斯检测仪检测到瓦斯浓度1.10%，超过阈值1.0%',                1.10, 1.00, 0, CURRENT_TIMESTAMP - INTERVAL '9' HOUR, NULL, NULL),
('ALM-20260928-006', 4,  2, 'TEMP_HIGH',    2, '吉林矿区1号采煤机温度33.4℃，接近阈值40℃',                              33.40, 40.00, 1, CURRENT_TIMESTAMP - INTERVAL '8' HOUR, 'admin', CURRENT_TIMESTAMP - INTERVAL '7' HOUR),
('ALM-20260928-007', 1,  1, 'TEMP_HIGH',    2, '长春矿区1号采煤机温度35.2℃，接近阈值40℃',                              35.20, 40.00, 0, CURRENT_TIMESTAMP - INTERVAL '1' HOUR, NULL, NULL),
('ALM-20260928-008', 10, 4, 'DEVICE_FAULT', 1, '通化矿区1号采煤机电流波动异常',                                          38.20, 48.60, 2, CURRENT_TIMESTAMP - INTERVAL '5' HOUR, 'admin', CURRENT_TIMESTAMP - INTERVAL '4' HOUR),
('ALM-20260928-009', 13, 5, 'TEMP_HIGH',    2, '延边矿区1号采煤机温度35.8℃，接近阈值40℃',                              35.80, 40.00, 0, CURRENT_TIMESTAMP - INTERVAL '25' MINUTE, NULL, NULL),
('ALM-20260928-010', 3,  1, 'GAS_OVER',     1, '长春矿区通风机瓦斯浓度0.25%，轻微波动',                                 0.25, 1.00, 2, CURRENT_TIMESTAMP - INTERVAL '2' HOUR, 'admin', CURRENT_TIMESTAMP - INTERVAL '1' HOUR);
