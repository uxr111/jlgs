@echo off
setlocal enabledelayedexpansion

REM Maven Wrapper for Windows (ASCII only, supports paths with spaces)

REM Set JAVA_HOME if not defined
if not defined JAVA_HOME (
    if exist "C:\Program Files\Java\jdk-21" set "JAVA_HOME=C:\Program Files\Java\jdk-21"
    if exist "C:\Program Files\Java\jdk-17" set "JAVA_HOME=C:\Program Files\Java\jdk-17"
)
if not defined JAVA_HOME (
    echo Error: JAVA_HOME not set and no JDK found. >&2
    exit /b 1
)
set "PATH=%JAVA_HOME%\bin;%PATH%"

REM Project base dir (%~dp0 has trailing backslash, supports spaces)
set "MAVEN_PROJECTBASEDIR=%~dp0"
set "WRAPPER_PROPERTIES=%MAVEN_PROJECTBASEDIR%.mvn\wrapper\maven-wrapper.properties"

if not exist "%WRAPPER_PROPERTIES%" (
    echo Error: maven-wrapper.properties not found at "%WRAPPER_PROPERTIES%" >&2
    exit /b 1
)

REM Read distributionUrl (usebackq handles paths with spaces)
set "DISTRIBUTION_URL="
for /f "usebackq tokens=1,* delims==" %%a in ("%WRAPPER_PROPERTIES%") do (
    if "%%a"=="distributionUrl" set "DISTRIBUTION_URL=%%b"
)

if not defined DISTRIBUTION_URL (
    echo Error: distributionUrl not found in maven-wrapper.properties >&2
    exit /b 1
)

REM Extract filename and version from URL
set "DISTRIBUTION_FILE="
for %%F in ("%DISTRIBUTION_URL%") do set "DISTRIBUTION_FILE=%%~nxF"
set "MAVEN_VERSION=%DISTRIBUTION_FILE:apache-maven=%"
set "MAVEN_VERSION=%MAVEN_VERSION:-bin.zip=%"

set "MAVEN_HOME=%USERPROFILE%\.m2\wrapper\maven\%MAVEN_VERSION%"

if exist "%MAVEN_HOME%\bin\mvn.cmd" goto runMaven

echo Downloading Apache Maven %MAVEN_VERSION% ...
set "MAVEN_ZIP=%TEMP%\%DISTRIBUTION_FILE%"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -Uri '%DISTRIBUTION_URL%' -OutFile '%MAVEN_ZIP%' -UseBasicParsing; $dest='%MAVEN_HOME%'; New-Item -ItemType Directory -Force -Path $dest | Out-Null; Expand-Archive -Path '%MAVEN_ZIP%' -DestinationPath '%MAVEN_HOME%\..' -Force; $extracted=Get-ChildItem -Path '%MAVEN_HOME%\..' -Directory -Filter 'apache-maven-*' | Select-Object -First 1; if ($extracted -and $extracted.FullName -ne $dest) { if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }; Move-Item -Path $extracted.FullName -Destination $dest -Force }; Write-Host 'Maven installed successfully'; } catch { Write-Error $_.Exception.Message; exit 1 }"

if errorlevel 1 (
    echo Error: Failed to download or install Maven. >&2
    exit /b 1
)

if not exist "%MAVEN_HOME%\bin\mvn.cmd" (
    echo Error: Maven installation failed - mvn.cmd not found at "%MAVEN_HOME%\bin" >&2
    exit /b 1
)

:runMaven
set "MAVEN_CMD=%MAVEN_HOME%\bin\mvn.cmd"
if not defined MAVEN_OPTS set "MAVEN_OPTS=-Xms256m -Xmx1024m"

call "%MAVEN_CMD%" %*
set "ERROR_CODE=%ERRORLEVEL%"

endlocal & exit /b %ERROR_CODE%
